var kt=Object.defineProperty;var Ue=r=>{throw TypeError(r)};var Dt=(r,e,t)=>e in r?kt(r,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):r[e]=t;var f=(r,e,t)=>Dt(r,typeof e!="symbol"?e+"":e,t),Oe=(r,e,t)=>e.has(r)||Ue("Cannot "+t);var u=(r,e,t)=>(Oe(r,e,"read from private field"),t?t.call(r):e.get(r)),x=(r,e,t)=>e.has(r)?Ue("Cannot add the same private member more than once"):e instanceof WeakSet?e.add(r):e.set(r,t),v=(r,e,t,s)=>(Oe(r,e,"write to private field"),s?s.call(r,t):e.set(r,t),t),_=(r,e,t)=>(Oe(r,e,"access private method"),t);var qe=(r,e,t,s)=>({set _(i){v(r,e,i,t)},get _(){return u(r,e,s)}});var ze=(r,e,t)=>(s,i)=>{let a=-1;return n(0);async function n(o){if(o<=a)throw new Error("next() called multiple times");a=o;let c,l=!1,d;if(r[o]?(d=r[o][0][0],s.req.routeIndex=o):d=o===r.length&&i||void 0,d)try{c=await d(s,()=>n(o+1))}catch(h){if(h instanceof Error&&e)s.error=h,c=await e(h,s),l=!0;else throw h}else s.finalized===!1&&t&&(c=await t(s));return c&&(s.finalized===!1||l)&&(s.res=c),s}},Pt=Symbol(),Rt=async(r,e=Object.create(null))=>{const{all:t=!1,dot:s=!1}=e,a=(r instanceof lt?r.raw.headers:r.headers).get("Content-Type");return a!=null&&a.startsWith("multipart/form-data")||a!=null&&a.startsWith("application/x-www-form-urlencoded")?At(r,{all:t,dot:s}):{}};async function At(r,e){const t=await r.formData();return t?It(t,e):{}}function It(r,e){const t=Object.create(null);return r.forEach((s,i)=>{e.all||i.endsWith("[]")?Mt(t,i,s):t[i]=s}),e.dot&&Object.entries(t).forEach(([s,i])=>{s.includes(".")&&($t(t,s,i),delete t[s])}),t}var Mt=(r,e,t)=>{r[e]!==void 0?Array.isArray(r[e])?r[e].push(t):r[e]=[r[e],t]:e.endsWith("[]")?r[e]=[t]:r[e]=t},$t=(r,e,t)=>{let s=r;const i=e.split(".");i.forEach((a,n)=>{n===i.length-1?s[a]=t:((!s[a]||typeof s[a]!="object"||Array.isArray(s[a])||s[a]instanceof File)&&(s[a]=Object.create(null)),s=s[a])})},it=r=>{const e=r.split("/");return e[0]===""&&e.shift(),e},Ot=r=>{const{groups:e,path:t}=Ht(r),s=it(t);return Nt(s,e)},Ht=r=>{const e=[];return r=r.replace(/\{[^}]+\}/g,(t,s)=>{const i=`@${s}`;return e.push([i,t]),i}),{groups:e,path:r}},Nt=(r,e)=>{for(let t=e.length-1;t>=0;t--){const[s]=e[t];for(let i=r.length-1;i>=0;i--)if(r[i].includes(s)){r[i]=r[i].replace(s,e[t][1]);break}}return r},Te={},Lt=(r,e)=>{if(r==="*")return"*";const t=r.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);if(t){const s=`${r}#${e}`;return Te[s]||(t[2]?Te[s]=e&&e[0]!==":"&&e[0]!=="*"?[s,t[1],new RegExp(`^${t[2]}(?=/${e})`)]:[r,t[1],new RegExp(`^${t[2]}$`)]:Te[s]=[r,t[1],!0]),Te[s]}return null},Fe=(r,e)=>{try{return e(r)}catch{return r.replace(/(?:%[0-9A-Fa-f]{2})+/g,t=>{try{return e(t)}catch{return t}})}},jt=r=>Fe(r,decodeURI),at=r=>{const e=r.url,t=e.indexOf("/",e.indexOf(":")+4);let s=t;for(;s<e.length;s++){const i=e.charCodeAt(s);if(i===37){const a=e.indexOf("?",s),n=e.slice(t,a===-1?void 0:a);return jt(n.includes("%25")?n.replace(/%25/g,"%2525"):n)}else if(i===63)break}return e.slice(t,s)},Ft=r=>{const e=at(r);return e.length>1&&e.at(-1)==="/"?e.slice(0,-1):e},se=(r,e,...t)=>(t.length&&(e=se(e,...t)),`${(r==null?void 0:r[0])==="/"?"":"/"}${r}${e==="/"?"":`${(r==null?void 0:r.at(-1))==="/"?"":"/"}${(e==null?void 0:e[0])==="/"?e.slice(1):e}`}`),nt=r=>{if(r.charCodeAt(r.length-1)!==63||!r.includes(":"))return null;const e=r.split("/"),t=[];let s="";return e.forEach(i=>{if(i!==""&&!/\:/.test(i))s+="/"+i;else if(/\:/.test(i))if(/\?/.test(i)){t.length===0&&s===""?t.push("/"):t.push(s);const a=i.replace("?","");s+="/"+a,t.push(s)}else s+="/"+i}),t.filter((i,a,n)=>n.indexOf(i)===a)},He=r=>/[%+]/.test(r)?(r.indexOf("+")!==-1&&(r=r.replace(/\+/g," ")),r.indexOf("%")!==-1?Fe(r,ct):r):r,ot=(r,e,t)=>{let s;if(!t&&e&&!/[%+]/.test(e)){let n=r.indexOf(`?${e}`,8);for(n===-1&&(n=r.indexOf(`&${e}`,8));n!==-1;){const o=r.charCodeAt(n+e.length+1);if(o===61){const c=n+e.length+2,l=r.indexOf("&",c);return He(r.slice(c,l===-1?void 0:l))}else if(o==38||isNaN(o))return"";n=r.indexOf(`&${e}`,n+1)}if(s=/[%+]/.test(r),!s)return}const i={};s??(s=/[%+]/.test(r));let a=r.indexOf("?",8);for(;a!==-1;){const n=r.indexOf("&",a+1);let o=r.indexOf("=",a);o>n&&n!==-1&&(o=-1);let c=r.slice(a+1,o===-1?n===-1?void 0:n:o);if(s&&(c=He(c)),a=n,c==="")continue;let l;o===-1?l="":(l=r.slice(o+1,n===-1?void 0:n),s&&(l=He(l))),t?(i[c]&&Array.isArray(i[c])||(i[c]=[]),i[c].push(l)):i[c]??(i[c]=l)}return e?i[e]:i},Bt=ot,Ut=(r,e)=>ot(r,e,!0),ct=decodeURIComponent,Ve=r=>Fe(r,ct),oe,P,F,dt,ut,Le,U,Ye,lt=(Ye=class{constructor(r,e="/",t=[[]]){x(this,F);f(this,"raw");x(this,oe);x(this,P);f(this,"routeIndex",0);f(this,"path");f(this,"bodyCache",{});x(this,U,r=>{const{bodyCache:e,raw:t}=this,s=e[r];if(s)return s;const i=Object.keys(e)[0];return i?e[i].then(a=>(i==="json"&&(a=JSON.stringify(a)),new Response(a)[r]())):e[r]=t[r]()});this.raw=r,this.path=e,v(this,P,t),v(this,oe,{})}param(r){return r?_(this,F,dt).call(this,r):_(this,F,ut).call(this)}query(r){return Bt(this.url,r)}queries(r){return Ut(this.url,r)}header(r){if(r)return this.raw.headers.get(r)??void 0;const e={};return this.raw.headers.forEach((t,s)=>{e[s]=t}),e}async parseBody(r){var e;return(e=this.bodyCache).parsedBody??(e.parsedBody=await Rt(this,r))}json(){return u(this,U).call(this,"text").then(r=>JSON.parse(r))}text(){return u(this,U).call(this,"text")}arrayBuffer(){return u(this,U).call(this,"arrayBuffer")}blob(){return u(this,U).call(this,"blob")}formData(){return u(this,U).call(this,"formData")}addValidatedData(r,e){u(this,oe)[r]=e}valid(r){return u(this,oe)[r]}get url(){return this.raw.url}get method(){return this.raw.method}get[Pt](){return u(this,P)}get matchedRoutes(){return u(this,P)[0].map(([[,r]])=>r)}get routePath(){return u(this,P)[0].map(([[,r]])=>r)[this.routeIndex].path}},oe=new WeakMap,P=new WeakMap,F=new WeakSet,dt=function(r){const e=u(this,P)[0][this.routeIndex][1][r],t=_(this,F,Le).call(this,e);return t?/\%/.test(t)?Ve(t):t:void 0},ut=function(){const r={},e=Object.keys(u(this,P)[0][this.routeIndex][1]);for(const t of e){const s=_(this,F,Le).call(this,u(this,P)[0][this.routeIndex][1][t]);s&&typeof s=="string"&&(r[t]=/\%/.test(s)?Ve(s):s)}return r},Le=function(r){return u(this,P)[1]?u(this,P)[1][r]:r},U=new WeakMap,Ye),qt={Stringify:1},ht=async(r,e,t,s,i)=>{typeof r=="object"&&!(r instanceof String)&&(r instanceof Promise||(r=r.toString()),r instanceof Promise&&(r=await r));const a=r.callbacks;return a!=null&&a.length?(i?i[0]+=r:i=[r],Promise.all(a.map(o=>o({phase:e,buffer:i,context:s}))).then(o=>Promise.all(o.filter(Boolean).map(c=>ht(c,e,!1,s,i))).then(()=>i[0]))):Promise.resolve(r)},zt="text/plain; charset=UTF-8",Ne=(r,e)=>({"Content-Type":r,...e}),be,xe,H,ce,N,D,_e,le,de,J,ye,we,q,ie,Je,Vt=(Je=class{constructor(r,e){x(this,q);x(this,be);x(this,xe);f(this,"env",{});x(this,H);f(this,"finalized",!1);f(this,"error");x(this,ce);x(this,N);x(this,D);x(this,_e);x(this,le);x(this,de);x(this,J);x(this,ye);x(this,we);f(this,"render",(...r)=>(u(this,le)??v(this,le,e=>this.html(e)),u(this,le).call(this,...r)));f(this,"setLayout",r=>v(this,_e,r));f(this,"getLayout",()=>u(this,_e));f(this,"setRenderer",r=>{v(this,le,r)});f(this,"header",(r,e,t)=>{this.finalized&&v(this,D,new Response(u(this,D).body,u(this,D)));const s=u(this,D)?u(this,D).headers:u(this,J)??v(this,J,new Headers);e===void 0?s.delete(r):t!=null&&t.append?s.append(r,e):s.set(r,e)});f(this,"status",r=>{v(this,ce,r)});f(this,"set",(r,e)=>{u(this,H)??v(this,H,new Map),u(this,H).set(r,e)});f(this,"get",r=>u(this,H)?u(this,H).get(r):void 0);f(this,"newResponse",(...r)=>_(this,q,ie).call(this,...r));f(this,"body",(r,e,t)=>_(this,q,ie).call(this,r,e,t));f(this,"text",(r,e,t)=>!u(this,J)&&!u(this,ce)&&!e&&!t&&!this.finalized?new Response(r):_(this,q,ie).call(this,r,e,Ne(zt,t)));f(this,"json",(r,e,t)=>_(this,q,ie).call(this,JSON.stringify(r),e,Ne("application/json",t)));f(this,"html",(r,e,t)=>{const s=i=>_(this,q,ie).call(this,i,e,Ne("text/html; charset=UTF-8",t));return typeof r=="object"?ht(r,qt.Stringify,!1,{}).then(s):s(r)});f(this,"redirect",(r,e)=>{const t=String(r);return this.header("Location",/[^\x00-\xFF]/.test(t)?encodeURI(t):t),this.newResponse(null,e??302)});f(this,"notFound",()=>(u(this,de)??v(this,de,()=>new Response),u(this,de).call(this,this)));v(this,be,r),e&&(v(this,N,e.executionCtx),this.env=e.env,v(this,de,e.notFoundHandler),v(this,we,e.path),v(this,ye,e.matchResult))}get req(){return u(this,xe)??v(this,xe,new lt(u(this,be),u(this,we),u(this,ye))),u(this,xe)}get event(){if(u(this,N)&&"respondWith"in u(this,N))return u(this,N);throw Error("This context has no FetchEvent")}get executionCtx(){if(u(this,N))return u(this,N);throw Error("This context has no ExecutionContext")}get res(){return u(this,D)||v(this,D,new Response(null,{headers:u(this,J)??v(this,J,new Headers)}))}set res(r){if(u(this,D)&&r){r=new Response(r.body,r);for(const[e,t]of u(this,D).headers.entries())if(e!=="content-type")if(e==="set-cookie"){const s=u(this,D).headers.getSetCookie();r.headers.delete("set-cookie");for(const i of s)r.headers.append("set-cookie",i)}else r.headers.set(e,t)}v(this,D,r),this.finalized=!0}get var(){return u(this,H)?Object.fromEntries(u(this,H)):{}}},be=new WeakMap,xe=new WeakMap,H=new WeakMap,ce=new WeakMap,N=new WeakMap,D=new WeakMap,_e=new WeakMap,le=new WeakMap,de=new WeakMap,J=new WeakMap,ye=new WeakMap,we=new WeakMap,q=new WeakSet,ie=function(r,e,t){const s=u(this,D)?new Headers(u(this,D).headers):u(this,J)??new Headers;if(typeof e=="object"&&"headers"in e){const a=e.headers instanceof Headers?e.headers:new Headers(e.headers);for(const[n,o]of a)n.toLowerCase()==="set-cookie"?s.append(n,o):s.set(n,o)}if(t)for(const[a,n]of Object.entries(t))if(typeof n=="string")s.set(a,n);else{s.delete(a);for(const o of n)s.append(a,o)}const i=typeof e=="number"?e:(e==null?void 0:e.status)??u(this,ce);return new Response(r,{status:i,headers:s})},Je),w="ALL",Gt="all",Wt=["get","post","put","delete","options","patch"],pt="Can not add a route since the matcher is already built.",mt=class extends Error{},Kt="__COMPOSED_HANDLER",Yt=r=>r.text("404 Not Found",404),Ge=(r,e)=>{if("getResponse"in r){const t=r.getResponse();return e.newResponse(t.body,t)}return console.error(r),e.text("Internal Server Error",500)},R,E,ft,A,K,Se,ke,Xe,gt=(Xe=class{constructor(e={}){x(this,E);f(this,"get");f(this,"post");f(this,"put");f(this,"delete");f(this,"options");f(this,"patch");f(this,"all");f(this,"on");f(this,"use");f(this,"router");f(this,"getPath");f(this,"_basePath","/");x(this,R,"/");f(this,"routes",[]);x(this,A,Yt);f(this,"errorHandler",Ge);f(this,"onError",e=>(this.errorHandler=e,this));f(this,"notFound",e=>(v(this,A,e),this));f(this,"fetch",(e,...t)=>_(this,E,ke).call(this,e,t[1],t[0],e.method));f(this,"request",(e,t,s,i)=>e instanceof Request?this.fetch(t?new Request(e,t):e,s,i):(e=e.toString(),this.fetch(new Request(/^https?:\/\//.test(e)?e:`http://localhost${se("/",e)}`,t),s,i)));f(this,"fire",()=>{addEventListener("fetch",e=>{e.respondWith(_(this,E,ke).call(this,e.request,e,void 0,e.request.method))})});[...Wt,Gt].forEach(a=>{this[a]=(n,...o)=>(typeof n=="string"?v(this,R,n):_(this,E,K).call(this,a,u(this,R),n),o.forEach(c=>{_(this,E,K).call(this,a,u(this,R),c)}),this)}),this.on=(a,n,...o)=>{for(const c of[n].flat()){v(this,R,c);for(const l of[a].flat())o.map(d=>{_(this,E,K).call(this,l.toUpperCase(),u(this,R),d)})}return this},this.use=(a,...n)=>(typeof a=="string"?v(this,R,a):(v(this,R,"*"),n.unshift(a)),n.forEach(o=>{_(this,E,K).call(this,w,u(this,R),o)}),this);const{strict:s,...i}=e;Object.assign(this,i),this.getPath=s??!0?e.getPath??at:Ft}route(e,t){const s=this.basePath(e);return t.routes.map(i=>{var n;let a;t.errorHandler===Ge?a=i.handler:(a=async(o,c)=>(await ze([],t.errorHandler)(o,()=>i.handler(o,c))).res,a[Kt]=i.handler),_(n=s,E,K).call(n,i.method,i.path,a)}),this}basePath(e){const t=_(this,E,ft).call(this);return t._basePath=se(this._basePath,e),t}mount(e,t,s){let i,a;s&&(typeof s=="function"?a=s:(a=s.optionHandler,s.replaceRequest===!1?i=c=>c:i=s.replaceRequest));const n=a?c=>{const l=a(c);return Array.isArray(l)?l:[l]}:c=>{let l;try{l=c.executionCtx}catch{}return[c.env,l]};i||(i=(()=>{const c=se(this._basePath,e),l=c==="/"?0:c.length;return d=>{const h=new URL(d.url);return h.pathname=h.pathname.slice(l)||"/",new Request(h,d)}})());const o=async(c,l)=>{const d=await t(i(c.req.raw),...n(c));if(d)return d;await l()};return _(this,E,K).call(this,w,se(e,"*"),o),this}},R=new WeakMap,E=new WeakSet,ft=function(){const e=new gt({router:this.router,getPath:this.getPath});return e.errorHandler=this.errorHandler,v(e,A,u(this,A)),e.routes=this.routes,e},A=new WeakMap,K=function(e,t,s){e=e.toUpperCase(),t=se(this._basePath,t);const i={basePath:this._basePath,path:t,method:e,handler:s};this.router.add(e,t,[s,i]),this.routes.push(i)},Se=function(e,t){if(e instanceof Error)return this.errorHandler(e,t);throw e},ke=function(e,t,s,i){if(i==="HEAD")return(async()=>new Response(null,await _(this,E,ke).call(this,e,t,s,"GET")))();const a=this.getPath(e,{env:s}),n=this.router.match(i,a),o=new Vt(e,{path:a,matchResult:n,env:s,executionCtx:t,notFoundHandler:u(this,A)});if(n[0].length===1){let l;try{l=n[0][0][0][0](o,async()=>{o.res=await u(this,A).call(this,o)})}catch(d){return _(this,E,Se).call(this,d,o)}return l instanceof Promise?l.then(d=>d||(o.finalized?o.res:u(this,A).call(this,o))).catch(d=>_(this,E,Se).call(this,d,o)):l??u(this,A).call(this,o)}const c=ze(n[0],this.errorHandler,u(this,A));return(async()=>{try{const l=await c(o);if(!l.finalized)throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");return l.res}catch(l){return _(this,E,Se).call(this,l,o)}})()},Xe),Pe="[^/]+",fe=".*",ve="(?:|/.*)",ae=Symbol(),Jt=new Set(".\\+*[^]$()");function Xt(r,e){return r.length===1?e.length===1?r<e?-1:1:-1:e.length===1||r===fe||r===ve?1:e===fe||e===ve?-1:r===Pe?1:e===Pe?-1:r.length===e.length?r<e?-1:1:e.length-r.length}var X,Z,I,Ze,je=(Ze=class{constructor(){x(this,X);x(this,Z);x(this,I,Object.create(null))}insert(e,t,s,i,a){if(e.length===0){if(u(this,X)!==void 0)throw ae;if(a)return;v(this,X,t);return}const[n,...o]=e,c=n==="*"?o.length===0?["","",fe]:["","",Pe]:n==="/*"?["","",ve]:n.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);let l;if(c){const d=c[1];let h=c[2]||Pe;if(d&&c[2]&&(h===".*"||(h=h.replace(/^\((?!\?:)(?=[^)]+\)$)/,"(?:"),/\((?!\?:)/.test(h))))throw ae;if(l=u(this,I)[h],!l){if(Object.keys(u(this,I)).some(p=>p!==fe&&p!==ve))throw ae;if(a)return;l=u(this,I)[h]=new je,d!==""&&v(l,Z,i.varIndex++)}!a&&d!==""&&s.push([d,u(l,Z)])}else if(l=u(this,I)[n],!l){if(Object.keys(u(this,I)).some(d=>d.length>1&&d!==fe&&d!==ve))throw ae;if(a)return;l=u(this,I)[n]=new je}l.insert(o,t,s,i,a)}buildRegExpStr(){const t=Object.keys(u(this,I)).sort(Xt).map(s=>{const i=u(this,I)[s];return(typeof u(i,Z)=="number"?`(${s})@${u(i,Z)}`:Jt.has(s)?`\\${s}`:s)+i.buildRegExpStr()});return typeof u(this,X)=="number"&&t.unshift(`#${u(this,X)}`),t.length===0?"":t.length===1?t[0]:"(?:"+t.join("|")+")"}},X=new WeakMap,Z=new WeakMap,I=new WeakMap,Ze),Re,Ee,Qe,Zt=(Qe=class{constructor(){x(this,Re,{varIndex:0});x(this,Ee,new je)}insert(r,e,t){const s=[],i=[];for(let n=0;;){let o=!1;if(r=r.replace(/\{[^}]+\}/g,c=>{const l=`@\\${n}`;return i[n]=[l,c],n++,o=!0,l}),!o)break}const a=r.match(/(?::[^\/]+)|(?:\/\*$)|./g)||[];for(let n=i.length-1;n>=0;n--){const[o]=i[n];for(let c=a.length-1;c>=0;c--)if(a[c].indexOf(o)!==-1){a[c]=a[c].replace(o,i[n][1]);break}}return u(this,Ee).insert(a,e,s,u(this,Re),t),s}buildRegExp(){let r=u(this,Ee).buildRegExpStr();if(r==="")return[/^$/,[],[]];let e=0;const t=[],s=[];return r=r.replace(/#(\d+)|@(\d+)|\.\*\$/g,(i,a,n)=>a!==void 0?(t[++e]=Number(a),"$()"):(n!==void 0&&(s[Number(n)]=++e),"")),[new RegExp(`^${r}`),t,s]}},Re=new WeakMap,Ee=new WeakMap,Qe),vt=[],Qt=[/^$/,[],Object.create(null)],De=Object.create(null);function bt(r){return De[r]??(De[r]=new RegExp(r==="*"?"":`^${r.replace(/\/\*$|([.\\+*[^\]$()])/g,(e,t)=>t?`\\${t}`:"(?:|/.*)")}$`))}function er(){De=Object.create(null)}function tr(r){var l;const e=new Zt,t=[];if(r.length===0)return Qt;const s=r.map(d=>[!/\*|\/:/.test(d[0]),...d]).sort(([d,h],[p,m])=>d?1:p?-1:h.length-m.length),i=Object.create(null);for(let d=0,h=-1,p=s.length;d<p;d++){const[m,b,g]=s[d];m?i[b]=[g.map(([k])=>[k,Object.create(null)]),vt]:h++;let y;try{y=e.insert(b,h,m)}catch(k){throw k===ae?new mt(b):k}m||(t[h]=g.map(([k,te])=>{const pe=Object.create(null);for(te-=1;te>=0;te--){const[M,Me]=y[te];pe[M]=Me}return[k,pe]}))}const[a,n,o]=e.buildRegExp();for(let d=0,h=t.length;d<h;d++)for(let p=0,m=t[d].length;p<m;p++){const b=(l=t[d][p])==null?void 0:l[1];if(!b)continue;const g=Object.keys(b);for(let y=0,k=g.length;y<k;y++)b[g[y]]=o[b[g[y]]]}const c=[];for(const d in n)c[d]=t[n[d]];return[a,c,i]}function re(r,e){if(r){for(const t of Object.keys(r).sort((s,i)=>i.length-s.length))if(bt(t).test(e))return[...r[t]]}}var z,V,he,xt,_t,et,rr=(et=class{constructor(){x(this,he);f(this,"name","RegExpRouter");x(this,z);x(this,V);v(this,z,{[w]:Object.create(null)}),v(this,V,{[w]:Object.create(null)})}add(r,e,t){var o;const s=u(this,z),i=u(this,V);if(!s||!i)throw new Error(pt);s[r]||[s,i].forEach(c=>{c[r]=Object.create(null),Object.keys(c[w]).forEach(l=>{c[r][l]=[...c[w][l]]})}),e==="/*"&&(e="*");const a=(e.match(/\/:/g)||[]).length;if(/\*$/.test(e)){const c=bt(e);r===w?Object.keys(s).forEach(l=>{var d;(d=s[l])[e]||(d[e]=re(s[l],e)||re(s[w],e)||[])}):(o=s[r])[e]||(o[e]=re(s[r],e)||re(s[w],e)||[]),Object.keys(s).forEach(l=>{(r===w||r===l)&&Object.keys(s[l]).forEach(d=>{c.test(d)&&s[l][d].push([t,a])})}),Object.keys(i).forEach(l=>{(r===w||r===l)&&Object.keys(i[l]).forEach(d=>c.test(d)&&i[l][d].push([t,a]))});return}const n=nt(e)||[e];for(let c=0,l=n.length;c<l;c++){const d=n[c];Object.keys(i).forEach(h=>{var p;(r===w||r===h)&&((p=i[h])[d]||(p[d]=[...re(s[h],d)||re(s[w],d)||[]]),i[h][d].push([t,a-l+c+1]))})}}match(r,e){er();const t=_(this,he,xt).call(this);return this.match=(s,i)=>{const a=t[s]||t[w],n=a[2][i];if(n)return n;const o=i.match(a[0]);if(!o)return[[],vt];const c=o.indexOf("",1);return[a[1][c],o]},this.match(r,e)}},z=new WeakMap,V=new WeakMap,he=new WeakSet,xt=function(){const r=Object.create(null);return Object.keys(u(this,V)).concat(Object.keys(u(this,z))).forEach(e=>{r[e]||(r[e]=_(this,he,_t).call(this,e))}),v(this,z,v(this,V,void 0)),r},_t=function(r){const e=[];let t=r===w;return[u(this,z),u(this,V)].forEach(s=>{const i=s[r]?Object.keys(s[r]).map(a=>[a,s[r][a]]):[];i.length!==0?(t||(t=!0),e.push(...i)):r!==w&&e.push(...Object.keys(s[w]).map(a=>[a,s[w][a]]))}),t?tr(e):null},et),G,L,tt,sr=(tt=class{constructor(r){f(this,"name","SmartRouter");x(this,G,[]);x(this,L,[]);v(this,G,r.routers)}add(r,e,t){if(!u(this,L))throw new Error(pt);u(this,L).push([r,e,t])}match(r,e){if(!u(this,L))throw new Error("Fatal error");const t=u(this,G),s=u(this,L),i=t.length;let a=0,n;for(;a<i;a++){const o=t[a];try{for(let c=0,l=s.length;c<l;c++)o.add(...s[c]);n=o.match(r,e)}catch(c){if(c instanceof mt)continue;throw c}this.match=o.match.bind(o),v(this,G,[o]),v(this,L,void 0);break}if(a===i)throw new Error("Fatal error");return this.name=`SmartRouter + ${this.activeRouter.name}`,n}get activeRouter(){if(u(this,L)||u(this,G).length!==1)throw new Error("No active router has been determined yet.");return u(this,G)[0]}},G=new WeakMap,L=new WeakMap,tt),ge=Object.create(null),W,S,Q,ue,C,j,Y,rt,yt=(rt=class{constructor(r,e,t){x(this,j);x(this,W);x(this,S);x(this,Q);x(this,ue,0);x(this,C,ge);if(v(this,S,t||Object.create(null)),v(this,W,[]),r&&e){const s=Object.create(null);s[r]={handler:e,possibleKeys:[],score:0},v(this,W,[s])}v(this,Q,[])}insert(r,e,t){v(this,ue,++qe(this,ue)._);let s=this;const i=Ot(e),a=[];for(let n=0,o=i.length;n<o;n++){const c=i[n],l=i[n+1],d=Lt(c,l),h=Array.isArray(d)?d[0]:c;if(h in u(s,S)){s=u(s,S)[h],d&&a.push(d[1]);continue}u(s,S)[h]=new yt,d&&(u(s,Q).push(d),a.push(d[1])),s=u(s,S)[h]}return u(s,W).push({[r]:{handler:t,possibleKeys:a.filter((n,o,c)=>c.indexOf(n)===o),score:u(this,ue)}}),s}search(r,e){var o;const t=[];v(this,C,ge);let i=[this];const a=it(e),n=[];for(let c=0,l=a.length;c<l;c++){const d=a[c],h=c===l-1,p=[];for(let m=0,b=i.length;m<b;m++){const g=i[m],y=u(g,S)[d];y&&(v(y,C,u(g,C)),h?(u(y,S)["*"]&&t.push(..._(this,j,Y).call(this,u(y,S)["*"],r,u(g,C))),t.push(..._(this,j,Y).call(this,y,r,u(g,C)))):p.push(y));for(let k=0,te=u(g,Q).length;k<te;k++){const pe=u(g,Q)[k],M=u(g,C)===ge?{}:{...u(g,C)};if(pe==="*"){const B=u(g,S)["*"];B&&(t.push(..._(this,j,Y).call(this,B,r,u(g,C))),v(B,C,M),p.push(B));continue}const[Me,Be,me]=pe;if(!d&&!(me instanceof RegExp))continue;const O=u(g,S)[Me],St=a.slice(c).join("/");if(me instanceof RegExp){const B=me.exec(St);if(B){if(M[Be]=B[0],t.push(..._(this,j,Y).call(this,O,r,u(g,C),M)),Object.keys(u(O,S)).length){v(O,C,M);const $e=((o=B[0].match(/\//))==null?void 0:o.length)??0;(n[$e]||(n[$e]=[])).push(O)}continue}}(me===!0||me.test(d))&&(M[Be]=d,h?(t.push(..._(this,j,Y).call(this,O,r,M,u(g,C))),u(O,S)["*"]&&t.push(..._(this,j,Y).call(this,u(O,S)["*"],r,M,u(g,C)))):(v(O,C,M),p.push(O)))}}i=p.concat(n.shift()??[])}return t.length>1&&t.sort((c,l)=>c.score-l.score),[t.map(({handler:c,params:l})=>[c,l])]}},W=new WeakMap,S=new WeakMap,Q=new WeakMap,ue=new WeakMap,C=new WeakMap,j=new WeakSet,Y=function(r,e,t,s){const i=[];for(let a=0,n=u(r,W).length;a<n;a++){const o=u(r,W)[a],c=o[e]||o[w],l={};if(c!==void 0&&(c.params=Object.create(null),i.push(c),t!==ge||s&&s!==ge))for(let d=0,h=c.possibleKeys.length;d<h;d++){const p=c.possibleKeys[d],m=l[c.score];c.params[p]=s!=null&&s[p]&&!m?s[p]:t[p]??(s==null?void 0:s[p]),l[c.score]=!0}}return i},rt),ee,st,ir=(st=class{constructor(){f(this,"name","TrieRouter");x(this,ee);v(this,ee,new yt)}add(r,e,t){const s=nt(e);if(s){for(let i=0,a=s.length;i<a;i++)u(this,ee).insert(r,s[i],t);return}u(this,ee).insert(r,e,t)}match(r,e){return u(this,ee).search(r,e)}},ee=new WeakMap,st),wt=class extends gt{constructor(r={}){super(r),this.router=r.router??new sr({routers:[new rr,new ir]})}},ar=r=>{const t={...{origin:"*",allowMethods:["GET","HEAD","PUT","POST","DELETE","PATCH"],allowHeaders:[],exposeHeaders:[]},...r},s=(a=>typeof a=="string"?a==="*"?()=>a:n=>a===n?n:null:typeof a=="function"?a:n=>a.includes(n)?n:null)(t.origin),i=(a=>typeof a=="function"?a:Array.isArray(a)?()=>a:()=>[])(t.allowMethods);return async function(n,o){var d;function c(h,p){n.res.headers.set(h,p)}const l=await s(n.req.header("origin")||"",n);if(l&&c("Access-Control-Allow-Origin",l),t.origin!=="*"){const h=n.req.header("Vary");h?c("Vary",h):c("Vary","Origin")}if(t.credentials&&c("Access-Control-Allow-Credentials","true"),(d=t.exposeHeaders)!=null&&d.length&&c("Access-Control-Expose-Headers",t.exposeHeaders.join(",")),n.req.method==="OPTIONS"){t.maxAge!=null&&c("Access-Control-Max-Age",t.maxAge.toString());const h=await i(n.req.header("origin")||"",n);h.length&&c("Access-Control-Allow-Methods",h.join(","));let p=t.allowHeaders;if(!(p!=null&&p.length)){const m=n.req.header("Access-Control-Request-Headers");m&&(p=m.split(/\s*,\s*/))}return p!=null&&p.length&&(c("Access-Control-Allow-Headers",p.join(",")),n.res.headers.append("Vary","Access-Control-Request-Headers")),n.res.headers.delete("Content-Length"),n.res.headers.delete("Content-Type"),new Response(null,{headers:n.res.headers,status:204,statusText:"No Content"})}await o()}},nr=/^\s*(?:text\/(?!event-stream(?:[;\s]|$))[^;\s]+|application\/(?:javascript|json|xml|xml-dtd|ecmascript|dart|postscript|rtf|tar|toml|vnd\.dart|vnd\.ms-fontobject|vnd\.ms-opentype|wasm|x-httpd-php|x-javascript|x-ns-proxy-autoconfig|x-sh|x-tar|x-virtualbox-hdd|x-virtualbox-ova|x-virtualbox-ovf|x-virtualbox-vbox|x-virtualbox-vdi|x-virtualbox-vhd|x-virtualbox-vmdk|x-www-form-urlencoded)|font\/(?:otf|ttf)|image\/(?:bmp|vnd\.adobe\.photoshop|vnd\.microsoft\.icon|vnd\.ms-dds|x-icon|x-ms-bmp)|message\/rfc822|model\/gltf-binary|x-shader\/x-fragment|x-shader\/x-vertex|[^;\s]+?\+(?:json|text|xml|yaml))(?:[;\s]|$)/i,We=(r,e=cr)=>{const t=/\.([a-zA-Z0-9]+?)$/,s=r.match(t);if(!s)return;let i=e[s[1]];return i&&i.startsWith("text")&&(i+="; charset=utf-8"),i},or={aac:"audio/aac",avi:"video/x-msvideo",avif:"image/avif",av1:"video/av1",bin:"application/octet-stream",bmp:"image/bmp",css:"text/css",csv:"text/csv",eot:"application/vnd.ms-fontobject",epub:"application/epub+zip",gif:"image/gif",gz:"application/gzip",htm:"text/html",html:"text/html",ico:"image/x-icon",ics:"text/calendar",jpeg:"image/jpeg",jpg:"image/jpeg",js:"text/javascript",json:"application/json",jsonld:"application/ld+json",map:"application/json",mid:"audio/x-midi",midi:"audio/x-midi",mjs:"text/javascript",mp3:"audio/mpeg",mp4:"video/mp4",mpeg:"video/mpeg",oga:"audio/ogg",ogv:"video/ogg",ogx:"application/ogg",opus:"audio/opus",otf:"font/otf",pdf:"application/pdf",png:"image/png",rtf:"application/rtf",svg:"image/svg+xml",tif:"image/tiff",tiff:"image/tiff",ts:"video/mp2t",ttf:"font/ttf",txt:"text/plain",wasm:"application/wasm",webm:"video/webm",weba:"audio/webm",webmanifest:"application/manifest+json",webp:"image/webp",woff:"font/woff",woff2:"font/woff2",xhtml:"application/xhtml+xml",xml:"application/xml",zip:"application/zip","3gp":"video/3gpp","3g2":"video/3gpp2",gltf:"model/gltf+json",glb:"model/gltf-binary"},cr=or,lr=(...r)=>{let e=r.filter(i=>i!=="").join("/");e=e.replace(new RegExp("(?<=\\/)\\/+","g"),"");const t=e.split("/"),s=[];for(const i of t)i===".."&&s.length>0&&s.at(-1)!==".."?s.pop():i!=="."&&s.push(i);return s.join("/")||"."},Et={br:".br",zstd:".zst",gzip:".gz"},dr=Object.keys(Et),ur="index.html",hr=r=>{const e=r.root??"./",t=r.path,s=r.join??lr;return async(i,a)=>{var d,h,p,m;if(i.finalized)return a();let n;if(r.path)n=r.path;else try{if(n=decodeURIComponent(i.req.path),/(?:^|[\/\\])\.\.(?:$|[\/\\])/.test(n))throw new Error}catch{return await((d=r.onNotFound)==null?void 0:d.call(r,i.req.path,i)),a()}let o=s(e,!t&&r.rewriteRequestPath?r.rewriteRequestPath(n):n);r.isDir&&await r.isDir(o)&&(o=s(o,ur));const c=r.getContent;let l=await c(o,i);if(l instanceof Response)return i.newResponse(l.body,l);if(l){const b=r.mimes&&We(o,r.mimes)||We(o);if(i.header("Content-Type",b||"application/octet-stream"),r.precompressed&&(!b||nr.test(b))){const g=new Set((h=i.req.header("Accept-Encoding"))==null?void 0:h.split(",").map(y=>y.trim()));for(const y of dr){if(!g.has(y))continue;const k=await c(o+Et[y],i);if(k){l=k,i.header("Content-Encoding",y),i.header("Vary","Accept-Encoding",{append:!0});break}}}return await((p=r.onFound)==null?void 0:p.call(r,o,i)),i.body(l)}await((m=r.onNotFound)==null?void 0:m.call(r,o,i)),await a()}},pr=async(r,e)=>{let t;e&&e.manifest?typeof e.manifest=="string"?t=JSON.parse(e.manifest):t=e.manifest:typeof __STATIC_CONTENT_MANIFEST=="string"?t=JSON.parse(__STATIC_CONTENT_MANIFEST):t=__STATIC_CONTENT_MANIFEST;let s;e&&e.namespace?s=e.namespace:s=__STATIC_CONTENT;const i=t[r]||r;if(!i)return null;const a=await s.get(i,{type:"stream"});return a||null},mr=r=>async function(t,s){return hr({...r,getContent:async a=>pr(a,{manifest:r.manifest,namespace:r.namespace?r.namespace:t.env?t.env.__STATIC_CONTENT:void 0})})(t,s)},gr=r=>mr(r);class fr{constructor(e,t=6e4){f(this,"calls",[]);f(this,"maxCalls");f(this,"timeWindow");this.maxCalls=Math.floor(e*.8),this.timeWindow=t}async acquire(){const e=Date.now();if(this.calls=this.calls.filter(t=>e-t<this.timeWindow),this.calls.length>=this.maxCalls){const t=this.calls[0],s=this.timeWindow-(e-t)+1e3;if(s>0)return await new Promise(i=>setTimeout(i,s)),this.acquire()}this.calls.push(e)}}const Ce={ETH:{coinGeckoId:"ethereum",symbol:"ETHUSDT",displayName:"Ethereum"},BTC:{coinGeckoId:"bitcoin",symbol:"BTCUSDT",displayName:"Bitcoin"}};class Ae{constructor(e){f(this,"config");f(this,"rateLimiter");this.config={apiKey:e,baseUrl:"https://pro-api.coingecko.com/api/v3",rateLimit:500},this.rateLimiter=new fr(this.config.rateLimit)}getCoinConfig(e){const t=Ce[e.toUpperCase()];if(!t)throw new Error(`Unsupported cryptocurrency: ${e}. Supported: ${Object.keys(Ce).join(", ")}`);return t}async makeRequest(e,t){await this.rateLimiter.acquire();const s=new URL(`${this.config.baseUrl}/${e}`);t&&Object.entries(t).forEach(([n,o])=>{o!=null&&s.searchParams.append(n,String(o))});const i={accept:"application/json","User-Agent":"Multi-Crypto-AI-Trader/3.1.0"};this.config.apiKey&&this.config.apiKey!=="demo"&&this.config.apiKey!=="undefined"&&(i["x-cg-pro-api-key"]=this.config.apiKey);let a=await fetch(s.toString(),{headers:i});if(a.status===401&&this.config.baseUrl.includes("pro-api")){console.warn("🔄 CoinGecko Pro API unauthorized, falling back to free API...");const n=s.toString().replace("pro-api.coingecko.com/api/v3","api.coingecko.com/api/v3");delete i["x-cg-pro-api-key"],a=await fetch(n,{headers:i}),a.ok&&console.log("✅ Successfully using CoinGecko free API")}if(a.status===429)return console.warn("CoinGecko rate limit hit, waiting..."),await new Promise(n=>setTimeout(n,6e4)),this.makeRequest(e,t);if(!a.ok)throw new Error(`CoinGecko API error: ${a.status} ${a.statusText}`);return a.json()}async getCryptoPriceData(e="ETH"){const s={ids:this.getCoinConfig(e).coinGeckoId,vs_currencies:"usd",include_market_cap:"true",include_24hr_vol:"true",include_24hr_change:"true",include_last_updated_at:"true"};return this.makeRequest("simple/price",s)}async getETHPriceData(){return this.getCryptoPriceData("ETH")}async getCryptoMarketData(e="ETH"){const t=this.getCoinConfig(e);return this.makeRequest(`coins/${t.coinGeckoId}`)}async getETHMarketData(){return this.getCryptoMarketData("ETH")}async getCryptoOHLCV(e="ETH",t=1){const s=this.getCoinConfig(e),i={vs_currency:"usd",days:t};return this.makeRequest(`coins/${s.coinGeckoId}/ohlc`,i)}async getETHOHLCV(e=1){return this.getCryptoOHLCV("ETH",e)}async getDerivativesData(e="ETH"){try{return{derivatives:(await this.makeRequest("derivatives")).filter(i=>i.symbol&&i.symbol.toUpperCase().includes(e.toUpperCase())),timestamp:new Date().toISOString()}}catch(t){return console.warn("Could not fetch derivatives:",t),{derivatives:[],timestamp:new Date().toISOString()}}}async getFearGreedIndex(){try{const e=await this.makeRequest("global");return{value:e.market_cap_change_percentage_24h_usd||0,classification:this.classifySentiment(e.market_cap_change_percentage_24h_usd||0)}}catch{return{value:null,classification:"neutral"}}}classifySentiment(e){return e>5?"extreme_greed":e>2?"greed":e>-2?"neutral":e>-5?"fear":"extreme_fear"}async getTrendingCoins(){return this.makeRequest("search/trending")}async getEnhancedMarketData(e="ETH"){try{console.log(`🔄 Fetching enhanced market data for ${e} from CoinGecko Pro...`);const t=await this.getCryptoPriceData(e);await new Promise(o=>setTimeout(o,200));const s=await this.getCryptoMarketData(e);await new Promise(o=>setTimeout(o,200));const i=await this.getDerivativesData(e);await new Promise(o=>setTimeout(o,200));const a=await this.getFearGreedIndex();await new Promise(o=>setTimeout(o,200));const n=await this.getTrendingCoins();return console.log(`✅ Enhanced market data for ${e} fetched successfully`),{price_data:t,market_data:s,derivatives:i,fear_greed:a,trending:n,timestamp:new Date().toISOString(),api_calls_used:5,crypto:e}}catch(t){return console.error(`❌ Enhanced market data fetch failed for ${e}:`,t),{error:t instanceof Error?t.message:"Unknown error",timestamp:new Date().toISOString(),crypto:e}}}async getCurrentCryptoPrice(e="ETH"){var t;try{const s=this.getCoinConfig(e);return((t=(await this.getCryptoPriceData(e))[s.coinGeckoId])==null?void 0:t.usd)||0}catch(s){return console.error(`Failed to get ${e} price:`,s),0}}async getCurrentETHPrice(){return this.getCurrentCryptoPrice("ETH")}async getCurrentBTCPrice(){return this.getCurrentCryptoPrice("BTC")}async getLatestCandle(e="ETH"){try{const t=await this.getCryptoOHLCV(e,1);if(!t||t.length===0)return null;const s=t[t.length-1];return{timestamp:new Date(s[0]),open:s[1],high:s[2],low:s[3],close:s[4],volume:0}}catch(t){return console.error(`Failed to get latest candle for ${e}:`,t),null}}async getRealHistoricalData(e="ETH",t=7){var s,i;try{console.log(`🔄 Fetching REAL ${t} days of historical market data for ${e} from CoinGecko Pro...`);const a=this.getCoinConfig(e),n=await this.getCryptoOHLCV(e,t);if(!n||n.length===0)throw new Error("No OHLC data received");let o=[];try{o=(await this.makeRequest(`coins/${a.coinGeckoId}/market_chart`,{vs_currency:"usd",days:t,interval:t>1?"hourly":"minutely"})).total_volumes||[],console.log(`📊 Retrieved ${o.length} volume data points for ${e}`)}catch{console.warn(`Could not fetch volume data for ${e}, using zero values`)}const c=n.map((l,d)=>{const h=l[0];let p=0;if(o.length>0){const m=o.find(([b,g])=>Math.abs(b-h)<36e5);p=m?m[1]:0}return{timestamp:new Date(h).toISOString(),open:Math.round(l[1]*100)/100,high:Math.round(l[2]*100)/100,low:Math.round(l[3]*100)/100,close:Math.round(l[4]*100)/100,volume:Math.round(p*100)/100}});return c.sort((l,d)=>new Date(l.timestamp).getTime()-new Date(d.timestamp).getTime()),console.log(`✅ Successfully formatted ${c.length} real historical data points for ${e}`),console.log(`📅 Data range: ${(s=c[0])==null?void 0:s.timestamp} to ${(i=c[c.length-1])==null?void 0:i.timestamp}`),c}catch(a){throw console.error(`❌ Real historical data fetch failed for ${e}:`,a),new Error(`Real historical data fetch failed for ${e}: ${a instanceof Error?a.message:"Unknown error"}`)}}async getLatestRealData(e="ETH",t=72){try{const s=Math.max(1,Math.ceil(t/24)),i=await this.getRealHistoricalData(e,s),a=Date.now()-t*60*60*1e3,n=i.filter(o=>new Date(o.timestamp).getTime()>=a);return console.log(`🕒 Filtered to ${n.length} data points from last ${t} hours for ${e}`),n}catch(s){throw console.error(`Failed to get latest real data for ${e}:`,s),s}}async initializeMassiveHistoricalData(e="ETH",t=450){var s,i;try{console.log(`🚀 Initializing ${t} historical data points for ${e} with alternative approach...`);const a=[],n=Math.ceil(t/48);console.log(`📦 Fetching ${n} blocks of 2-day data to reach ${t} points for ${e}`);for(let c=0;c<n&&a.length<t;c++)try{console.log(`📊 Fetching ${e} block ${c+1}/${n}...`);const l=await this.getRealHistoricalData(e,2);if(l&&l.length>0){const d=l.filter(h=>!a.some(p=>p.timestamp===h.timestamp));a.push(...d),console.log(`📈 ${e} Block ${c+1}: +${d.length} points (total: ${a.length})`)}c<n-1&&await new Promise(d=>setTimeout(d,1e3))}catch(l){console.warn(`⚠️ ${e} Block ${c+1} failed, continuing:`,l)}const o=a.sort((c,l)=>new Date(l.timestamp).getTime()-new Date(c.timestamp).getTime()).slice(0,t).reverse();return console.log(`✅ Retrieved ${o.length} points for ${e} initialization`),console.log(`📊 ${e} Data range: ${(s=o[0])==null?void 0:s.timestamp} → ${(i=o[o.length-1])==null?void 0:i.timestamp}`),o}catch(a){console.error(`❌ Failed to initialize massive historical data for ${e}:`,a),console.log(`🔄 Attempting fallback to current ${e} data...`);try{const n=await this.getCurrentCryptoPrice(e);if(n){console.log(`📊 Generating basic data points from current ${e} price as emergency fallback`);const o=[],c=Date.now();for(let l=t-1;l>=0;l--){const d=new Date(c-l*60*60*1e3),h=(Math.random()-.5)*.02,p=n*(1+h);o.push({timestamp:d.toISOString(),open:p,high:p*1.005,low:p*.995,close:p,volume:1e3+Math.random()*1e3})}return console.log(`🆘 Fallback generated ${o.length} basic data points for ${e}`),o}}catch(n){console.error(`❌ ${e} Fallback also failed:`,n)}throw new Error(`All ${e} initialization methods failed: ${a instanceof Error?a.message:"Unknown error"}`)}}async getIncrementalData(e="ETH",t){try{const s=new Date(t),i=Date.now(),a=Math.ceil((i-s.getTime())/(1e3*60*60));if(console.log(`🔄 Getting incremental ${e} data since ${t} (${a} hours ago)`),a<=0)return console.log(`⏭️ No new ${e} data needed - already up to date`),[];const o=(await this.getLatestRealData(e,Math.min(a+2,72))).filter(c=>new Date(c.timestamp).getTime()>s.getTime());return console.log(`📈 Found ${o.length} new incremental ${e} points`),o}catch(s){throw console.error(`Failed to get incremental ${e} data:`,s),new Error(`Incremental ${e} data fetch failed: ${s instanceof Error?s.message:"Unknown error"}`)}}async getDataSyncStatus(){const e=this.rateLimiter.calls.length,t=Math.max(0,450-e),s=t<50?6e4:0;return{last_api_call:new Date,calls_remaining_estimate:t,recommended_delay_ms:s}}static getSupportedCryptos(){return Object.keys(Ce)}static getCryptoInfo(e){return Ce[e.toUpperCase()]||null}}class Ie{constructor(e){f(this,"db");this.db=e}getCryptoSymbol(e){return e.includes("USDT")||e.includes("USD")?e:{ETH:"ETHUSDT",BTC:"BTCUSDT",ETHEREUM:"ETHUSDT",BITCOIN:"BTCUSDT"}[e.toUpperCase()]||e}async predictNextHours(e="ETHUSDT",t=24,s){const i=Date.now(),a=this.getCryptoSymbol(e);try{await this.logTimesFMCall("Starting TimesFM prediction",{symbol:a,originalSymbol:e,horizonHours:t,currentPrice:s,timestamp:new Date().toISOString()});const n=await this.getHistoricalData(a,504);if(n.length<100)return await this.logTimesFMCall("Insufficient historical data for TimesFM",{dataPoints:n.length,required:100,recommended:400,fallback:"neutral_prediction"}),this.createNeutralPrediction(a,s,t);const o=this.calculateTechnicalIndicators(n),c=this.analyzeTrend(n),l=this.generatePrediction(a,s,t,o,c),d=Date.now()-i;return await this.logTimesFMCall("TimesFM prediction completed",{predicted_price:l.predicted_price,predicted_return:l.predicted_return,confidence_score:l.confidence_score,execution_time_ms:d,indicators_used:Object.keys(o).length,trend_direction:c.direction,trend_strength:c.strength}),await this.savePrediction(l),l}catch(n){const o=Date.now()-i;return await this.logTimesFMCall("TimesFM prediction error",{error:n instanceof Error?n.message:"Unknown error",execution_time_ms:o,fallback:"neutral_prediction"}),console.error("Error in TimesFM prediction:",n),this.createNeutralPrediction(a,s,t)}}async getHistoricalData(e,t){try{const s=new Date;return s.setHours(s.getHours()-t),(await this.db.prepare(`
        SELECT * FROM market_data 
        WHERE symbol = ? AND timestamp >= ? 
        ORDER BY timestamp ASC
      `).bind(e,s.toISOString()).all()).results.map(a=>({symbol:a.symbol,timestamp:new Date(a.timestamp),open:a.open_price,high:a.high_price,low:a.low_price,close:a.close_price,volume:a.volume||0,market_cap:a.market_cap,fear_greed:a.fear_greed_index}))}catch(s){return console.error("Error getting historical data:",s),[]}}calculateTechnicalIndicators(e){if(e.length<20)throw new Error("Insufficient data for technical analysis");const t=e.map(a=>a.close),s=e.map(a=>a.high),i=e.map(a=>a.low);return{rsi:this.calculateRSI(t,14),ema20:this.calculateEMA(t,20),ema50:this.calculateEMA(t,50),bollingerUpper:this.calculateBollingerBands(t,20).upper,bollingerLower:this.calculateBollingerBands(t,20).lower,atr:this.calculateATR(s,i,t,14),momentum:this.calculateMomentum(t,10),volatility:this.calculateVolatility(t,20)}}analyzeTrend(e){const s=e.map(h=>h.close).slice(-20),i=s[0],n=(s[s.length-1]-i)/i;let o="sideways";n>.02?o="bullish":n<-.02&&(o="bearish");const c=Math.abs(n)*10,l=Math.min(...s.slice(-10)),d=Math.max(...s.slice(-10));return{direction:o,strength:Math.min(c,1),support:l,resistance:d}}generatePrediction(e,t,s,i,a){let n=0,o=.5,c=0;i.rsi>75?(n-=.025,o+=.15,c++):i.rsi>65?(n-=.015,o+=.1,c+=.5):i.rsi<25?(n+=.025,o+=.15,c++):i.rsi<35&&(n+=.015,o+=.1,c+=.5);const l=(i.ema20-i.ema50)/i.ema50;t>i.ema20&&i.ema20>i.ema50?(n+=.015+l*.5,o+=.12,c++):t<i.ema20&&i.ema20<i.ema50&&(n-=.015-Math.abs(l)*.5,o+=.12,c++);const d=(i.bollingerUpper-i.bollingerLower)/t;t>i.bollingerUpper?(n-=.02*(1+d),o+=.1,c+=.7):t<i.bollingerLower&&(n+=.02*(1+d),o+=.1,c+=.7),a.direction==="bullish"?(n+=a.strength*.03,o+=.15,c+=a.strength):a.direction==="bearish"&&(n-=a.strength*.03,o+=.15,c+=a.strength),Math.abs(i.momentum)>.01&&(n+=i.momentum*.8,o+=Math.min(Math.abs(i.momentum)*10,.1),c+=.5);const h=Math.min(i.volatility*s/24,.6);n*=1+h*.8;const p=Math.sqrt(s/24);n*=p,c>=2?o+=.15:c>=1.5&&(o+=.1),n=Math.max(-.15,Math.min(.15,n)),o=Math.max(.4,Math.min(.95,o)),Math.abs(n)<.005&&(n=i.momentum*.5,n=Math.max(-.02,Math.min(.02,n)));const m=t*(1+n);return{symbol:e,timestamp:new Date,predicted_price:m,predicted_return:n,confidence_score:o,horizon_hours:s,quantile_10:m*(1-Math.abs(n)*.7),quantile_90:m*(1+Math.abs(n)*.7)}}createNeutralPrediction(e,t,s){return{symbol:e,timestamp:new Date,predicted_price:t,predicted_return:0,confidence_score:.5,horizon_hours:s,quantile_10:t*.98,quantile_90:t*1.02}}async savePrediction(e){try{await this.db.prepare(`
        INSERT INTO predictions 
        (symbol, timestamp, predicted_price, predicted_return, confidence_score, 
         horizon_hours, quantile_10, quantile_90)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(e.symbol,e.timestamp.toISOString(),e.predicted_price,e.predicted_return,e.confidence_score,e.horizon_hours,e.quantile_10||null,e.quantile_90||null).run()}catch(t){console.error("Error saving prediction:",t)}}calculateRSI(e,t=14){if(e.length<t+1)return 50;let s=0,i=0;for(let c=1;c<=t;c++){const l=e[e.length-c]-e[e.length-c-1];l>0?s+=l:i+=Math.abs(l)}const a=s/t,n=i/t;return n===0?100:100-100/(1+a/n)}calculateEMA(e,t){if(e.length<t)return e[e.length-1];const s=2/(t+1);let i=e.slice(-t).reduce((a,n)=>a+n,0)/t;for(let a=e.length-t+1;a<e.length;a++)i=(e[a]-i)*s+i;return i}calculateBollingerBands(e,t=20){if(e.length<t){const c=e.reduce((l,d)=>l+d,0)/e.length;return{upper:c*1.02,lower:c*.98}}const s=e.slice(-t),i=s.reduce((c,l)=>c+l,0)/t,n=s.map(c=>Math.pow(c-i,2)).reduce((c,l)=>c+l,0)/t,o=Math.sqrt(n);return{upper:i+o*2,lower:i-o*2}}calculateATR(e,t,s,i=14){if(e.length<i+1)return 0;const a=[];for(let o=1;o<e.length;o++){const c=e[o]-t[o],l=Math.abs(e[o]-s[o-1]),d=Math.abs(t[o]-s[o-1]);a.push(Math.max(c,l,d))}return a.slice(-i).reduce((o,c)=>o+c,0)/i}calculateMomentum(e,t=10){if(e.length<t+1)return 0;const s=e[e.length-1],i=e[e.length-t-1];return(s-i)/i}calculateVolatility(e,t=20){if(e.length<t)return 0;const s=e.slice(-t),i=[];for(let o=1;o<s.length;o++)i.push((s[o]-s[o-1])/s[o-1]);const a=i.reduce((o,c)=>o+c,0)/i.length,n=i.reduce((o,c)=>o+Math.pow(c-a,2),0)/i.length;return Math.sqrt(n)*Math.sqrt(365*24)}async getLatestPredictions(e=5){try{return(await this.db.prepare(`
        SELECT * FROM predictions 
        ORDER BY timestamp DESC 
        LIMIT ?
      `).bind(e).all()).results.map(s=>({symbol:s.symbol,timestamp:new Date(s.timestamp),predicted_price:s.predicted_price,predicted_return:s.predicted_return,confidence_score:s.confidence_score,horizon_hours:s.horizon_hours,quantile_10:s.quantile_10,quantile_90:s.quantile_90}))}catch(t){return console.error("Error getting latest predictions:",t),[]}}async logTimesFMCall(e,t){try{await this.db.prepare(`
        INSERT INTO system_logs 
        (level, component, message, context_data, execution_time_ms, timestamp)
        VALUES (?, ?, ?, ?, ?, ?)
      `).bind("INFO","timesfm",e,JSON.stringify(t),t.execution_time_ms||null,new Date().toISOString()).run()}catch(s){console.error("Error logging TimesFM call:",s)}}}class Tt{constructor(e,t){f(this,"db");f(this,"config");this.db=e,this.config={initialBalance:parseFloat(t.INITIAL_BALANCE||"10000"),feesPerSide:parseFloat(t.FEES_BPS_PER_SIDE||"8"),maxPositionSize:1,stopLossPercent:5,takeProfitPercent:15,volatilityTarget:parseFloat(t.VOLATILITY_TARGET||"0.30")}}async generateSignal(e="ETHUSDT",t){try{const s=await this.db.prepare(`
        SELECT * FROM predictions 
        WHERE symbol = ? 
        ORDER BY timestamp DESC 
        LIMIT 1
      `).bind(e).first();if(!s)throw new Error("No recent prediction available");let i=t;if(!i){const g=await this.db.prepare(`
          SELECT close_price FROM market_data 
          WHERE symbol = ? 
          ORDER BY timestamp DESC 
          LIMIT 1
        `).bind(e).first();i=(g==null?void 0:g.close_price)||s.predicted_price}const a=s.predicted_return,n=s.confidence_score;let o="hold";const c=.59,l=.012,d=s.predicted_price,h=Math.abs(d-i)/i;n>=c&&h>=l&&(a>l?o="buy":a<-l&&(o="sell"));const p=n<.5&&Math.abs(a)<.005;p&&await this.checkLowConfidencePositions(e,n);const m=o==="buy"?i*(1-this.config.stopLossPercent/100):i*(1+this.config.stopLossPercent/100),b=o==="buy"?i*(1+this.config.takeProfitPercent/100):i*(1-this.config.takeProfitPercent/100);return{action:o,confidence:n,price:i,timestamp:new Date,symbol:e,predicted_return:a,predicted_price:d,price_difference_percent:h*100,stop_loss:o!=="hold"?m:void 0,take_profit:o!=="hold"?b:void 0,should_close_low_confidence:p||!1}}catch(s){return console.error("Error generating signal:",s),{action:"hold",confidence:0,price:0,timestamp:new Date,symbol:e}}}async shouldClosePosition(e,t){try{if(e.status!=="open")return{close:!1};if(e.stop_loss_price){if(e.side==="long"&&t<=e.stop_loss_price)return{close:!0,reason:"stop_loss"};if(e.side==="short"&&t>=e.stop_loss_price)return{close:!0,reason:"stop_loss"}}if(e.take_profit_price){if(e.side==="long"&&t>=e.take_profit_price)return{close:!0,reason:"take_profit"};if(e.side==="short"&&t<=e.take_profit_price)return{close:!0,reason:"take_profit"}}return{close:!1}}catch(s){return console.error("Error checking position closure conditions:",s),{close:!1}}}async checkLowConfidencePositions(e,t){try{const s=await this.getActivePositions(e);if(s.length===0)return;if(t<.4){console.log(`Low confidence (${t}), closing all positions for ${e}`);for(const i of s){const a=await this.db.prepare(`
            SELECT close_price FROM market_data 
            WHERE symbol = ? 
            ORDER BY timestamp DESC 
            LIMIT 1
          `).bind(e).first(),n=a==null?void 0:a.close_price;n&&i.id&&await this.closePosition(i.id,n,"low_confidence")}}await this.db.prepare(`
        INSERT INTO system_logs 
        (timestamp, level, component, message, context_data)
        VALUES (CURRENT_TIMESTAMP, 'INFO', 'trading', 'Low confidence position check', ?)
      `).bind(JSON.stringify({symbol:e,confidence:t,open_positions:s.length,action:t<.4?"positions_closed":"no_action"})).run()}catch(s){console.error("Error checking low confidence positions:",s)}}async executePaperTrade(e){if(e.action==="hold")return null;try{const t=await this.getActivePosition(e.symbol);if(t)if(t.side==="long"&&e.action==="sell"||t.side==="short"&&e.action==="buy")await this.closePosition(t.id,e.price,"signal_change");else return console.log("Position already open in same direction"),null;const i=await this.getCurrentBalance(e.symbol)*this.config.maxPositionSize,a=i/e.price,n=i*this.config.feesPerSide/1e4,o={symbol:e.symbol,side:e.action==="buy"?"long":"short",entry_price:e.price,quantity:a,status:"open",fees:n,opened_at:new Date},c=await this.db.prepare(`
        INSERT INTO paper_trades 
        (symbol, side, entry_price, quantity, status, fees, opened_at, stop_loss_price, take_profit_price)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(o.symbol,o.side,o.entry_price,o.quantity,o.status,o.fees,o.opened_at.toISOString(),e.stop_loss||null,e.take_profit||null).run();return o.id=c.meta.last_row_id,console.log(`✅ Paper trade executed: ${e.action} ${a.toFixed(4)} ${e.symbol} at $${e.price}`),o}catch(t){throw console.error("Error executing paper trade:",t),t}}async closePosition(e,t,s){try{const i=await this.db.prepare(`
        SELECT * FROM paper_trades WHERE id = ? AND status = 'open'
      `).bind(e).first();if(!i)throw new Error(`No open position found with id ${e}`);const a=i,o=(a.side==="long"?t-a.entry_price:a.entry_price-t)*a.quantity,c=t*a.quantity*this.config.feesPerSide/1e4,l=a.fees+c,d=o-l;return await this.db.prepare(`
        UPDATE paper_trades 
        SET exit_price = ?, status = 'closed', gross_pnl = ?, fees = ?, net_pnl = ?, 
            closed_at = ?, exit_reason = ?
        WHERE id = ?
      `).bind(t,o,l,d,new Date().toISOString(),s,e).run(),console.log(`✅ Position closed: ${a.side} ${a.quantity.toFixed(4)} ${a.symbol} - P&L: $${d.toFixed(2)}`),{...a,exit_price:t,gross_pnl:o,fees:l,net_pnl:d,closed_at:new Date,exit_reason:s,status:"closed"}}catch(i){throw console.error("Error closing position:",i),i}}async checkStopLossAndTakeProfit(e){try{const t=await this.db.prepare(`
        SELECT * FROM paper_trades 
        WHERE status = 'open' AND (stop_loss_price IS NOT NULL OR take_profit_price IS NOT NULL)
      `).all();for(const s of t.results){const i=s;let a=!1,n="";i.stop_loss_price&&(i.side==="long"&&e<=i.stop_loss_price||i.side==="short"&&e>=i.stop_loss_price)&&(a=!0,n="stop_loss"),i.take_profit_price&&!a&&(i.side==="long"&&e>=i.take_profit_price||i.side==="short"&&e<=i.take_profit_price)&&(a=!0,n="take_profit"),a&&await this.closePosition(i.id,e,n)}}catch(t){console.error("Error checking stop loss/take profit:",t)}}async getActivePosition(e){try{let t="SELECT * FROM paper_trades WHERE status = 'open'";const s=[];return e&&(t+=" AND symbol = ?",s.push(e)),t+=" ORDER BY opened_at DESC LIMIT 1",s.length>0?await this.db.prepare(t).bind(...s).first():await this.db.prepare(t).first()}catch(t){return console.error("Error getting active position:",t),null}}async getActivePositions(e){try{let t="SELECT * FROM paper_trades WHERE status = 'open'";const s=[];return e&&(t+=" AND symbol = ?",s.push(e)),t+=" ORDER BY opened_at DESC",(s.length>0?await this.db.prepare(t).bind(...s).all():await this.db.prepare(t).all()).results}catch(t){return console.error("Error getting active positions:",t),[]}}async getCurrentBalance(e){try{let t="SELECT COALESCE(SUM(net_pnl), 0) as total_pnl FROM paper_trades WHERE status = 'closed'";const s=[];e&&(t+=" AND symbol = ?",s.push(e));const i=s.length>0?await this.db.prepare(t).bind(...s).first():await this.db.prepare(t).first();return this.config.initialBalance+((i==null?void 0:i.total_pnl)||0)}catch(t){return console.error("Error getting current balance:",t),this.config.initialBalance}}async getPerformanceMetrics(e=30,t){try{const s=new Date;s.setDate(s.getDate()-e);let i=`
        SELECT 
          COUNT(*) as total_trades,
          SUM(CASE WHEN net_pnl > 0 THEN 1 ELSE 0 END) as winning_trades,
          SUM(CASE WHEN net_pnl <= 0 THEN 1 ELSE 0 END) as losing_trades,
          COALESCE(SUM(gross_pnl), 0) as total_pnl,
          COALESCE(SUM(net_pnl), 0) as net_pnl,
          COALESCE(AVG(CASE WHEN net_pnl > 0 THEN net_pnl END), 0) as avg_win,
          COALESCE(AVG(CASE WHEN net_pnl <= 0 THEN ABS(net_pnl) END), 0) as avg_loss
        FROM paper_trades 
        WHERE status = 'closed' AND closed_at >= ?`;const a=[s.toISOString()];t&&(i+=" AND symbol = ?",a.push(t));const n=await this.db.prepare(i).bind(...a).first(),o=(n==null?void 0:n.total_trades)||0,c=(n==null?void 0:n.winning_trades)||0,l=(n==null?void 0:n.losing_trades)||0,d=o>0?c/o:0,h=(n==null?void 0:n.avg_win)||0,p=(n==null?void 0:n.avg_loss)||0,m=p>0?h/p:0,b=await this.calculateMaxDrawdown();return{total_trades:o,winning_trades:c,losing_trades:l,win_rate:d,total_pnl:(n==null?void 0:n.total_pnl)||0,net_pnl:(n==null?void 0:n.net_pnl)||0,max_drawdown:b,profit_factor:m}}catch(s){return console.error("Error getting performance metrics:",s),{total_trades:0,winning_trades:0,losing_trades:0,win_rate:0,total_pnl:0,net_pnl:0,max_drawdown:0,profit_factor:0}}}async calculateMaxDrawdown(){try{const e=await this.db.prepare(`
        SELECT net_pnl, closed_at FROM paper_trades 
        WHERE status = 'closed' 
        ORDER BY closed_at ASC
      `).all();if(!e.results.length)return 0;let t=this.config.initialBalance,s=t,i=0;for(const a of e.results){t+=a.net_pnl,t>s&&(s=t);const o=(s-t)/s;o>i&&(i=o)}return i}catch(e){return console.error("Error calculating max drawdown:",e),0}}async getRecentTrades(e=10,t){try{let s="SELECT * FROM paper_trades WHERE status = 'closed'";const i=[];return t&&(s+=" AND symbol = ?",i.push(t)),s+=" ORDER BY closed_at DESC LIMIT ?",i.push(e),(await this.db.prepare(s).bind(...i).all()).results}catch(s){return console.error("Error getting recent trades:",s),[]}}calculateProfitProbability(e,t,s){try{const{side:i,entry_price:a,take_profit_price:n}=e;if(!n)return .5;const o=i==="long"?(n-s)/s:(s-n)/s,c=i==="long"?t.predicted_return:-t.predicted_return,l=t.confidence_score,d=c>0?Math.min(c/o,2):0;let p=l*.5+d*.3+.8*.2;return p=Math.max(0,Math.min(1,p)),p}catch(i){return console.warn("Error calculating profit probability:",i),.5}}shouldClosePositionWithPrediction(e,t,s){const i=[];try{e.stop_loss_price&&(e.side==="long"&&s<=e.stop_loss_price||e.side==="short"&&s>=e.stop_loss_price)&&i.push("stop_loss"),e.take_profit_price&&(e.side==="long"&&s>=e.take_profit_price||e.side==="short"&&s<=e.take_profit_price)&&i.push("take_profit"),t.confidence_score<.3&&i.push("low_confidence"),this.calculateProfitProbability(e,t,s)<.4&&i.push("low_profit_probability");const n=e.side==="long"?1:-1;t.predicted_return*n<-.015&&i.push("negative_outlook");const c=this.evaluateSignalFromPrediction(t);return(e.side==="long"&&c==="sell"||e.side==="short"&&c==="buy")&&i.push("opposite_signal"),{shouldClose:i.length>0,reasons:i}}catch(a){return console.error("Error evaluating position closure:",a),{shouldClose:!1,reasons:["evaluation_error"]}}}evaluateSignalFromPrediction(e){const{predicted_return:t,confidence_score:s}=e,i=.5,a=.012;if(s>=i){if(t>a)return"buy";if(t<-a)return"sell"}return"hold"}async checkAndClosePositionsIntelligent(e,t){try{const s=await this.db.prepare(`
        SELECT * FROM paper_trades WHERE status = 'open'
      `).all(),i={positions_checked:s.results.length,positions_closed:0,closures:[]};for(const a of s.results){const n=a,o=this.shouldClosePositionWithPrediction(n,e,t);if(o.shouldClose)try{const c=await this.closePosition(n.id,t,o.reasons.join(","));i.positions_closed++,i.closures.push({id:n.id,reasons:o.reasons,pnl:c.net_pnl||0}),await this.db.prepare(`
              INSERT INTO system_logs (timestamp, level, component, message, context_data)
              VALUES (CURRENT_TIMESTAMP, 'INFO', 'trading', 'Intelligent position closure', ?)
            `).bind(JSON.stringify({position_id:n.id,side:n.side,entry_price:n.entry_price,exit_price:t,reasons:o.reasons,pnl:c.net_pnl||0,profit_probability:this.calculateProfitProbability(n,e,t)})).run().catch(()=>{}),console.log(`🧠 Intelligent closure: ${n.side} position (${o.reasons.join(",")}) - P&L: $${(c.net_pnl||0).toFixed(2)}`)}catch(c){console.error(`Error closing position ${n.id}:`,c)}}return i}catch(s){return console.error("Error in intelligent position check:",s),{positions_checked:0,positions_closed:0,closures:[]}}}}const T=new wt;let $=[],ne=[];T.use("/api/*",ar({origin:"*",allowMethods:["GET","POST","PUT","DELETE","OPTIONS"],allowHeaders:["Content-Type","Authorization","X-Auth-Token"]}));T.use("/static/*",gr({root:"./public"}));T.get("/api/health",r=>r.json({status:"healthy",timestamp:new Date().toISOString(),version:"6.0.0-STANDALONE-REDIRECT",project:"eth-trader-v2",interface:"standalone"}));T.get("/api/market/ETH",async r=>{var e;try{const s=await new Ae(r.env.COINGECKO_API_KEY||"CG-bsLZ4jVKKU72L2Jmn2jSgioV").getEnhancedMarketData("ETH");if((e=s.price_data)!=null&&e.ethereum){const i=s.price_data.ethereum,a=i.usd_24h_change||0,n=i.usd?i.usd*a/100:0;return r.json({success:!0,crypto:"ETH",symbol:"ETHUSDT",price:i.usd,price_change_24h:n,price_change_percentage_24h:a,volume_24h:i.usd_24h_vol||0,market_cap:i.usd_market_cap||0,timestamp:new Date().toISOString(),status:"active",data:{symbol:"ETHUSDT",price:i.usd,price_change_24h:n,price_change_percentage_24h:a,volume_24h:i.usd_24h_vol||0,market_cap:i.usd_market_cap||0,timestamp:new Date().toISOString()}})}return r.json({success:!0,crypto:"ETH",price:4620.5,timestamp:new Date().toISOString(),status:"active"})}catch(t){return r.json({success:!1,error:t instanceof Error?t.message:"Market data unavailable",timestamp:new Date().toISOString()})}});T.get("/api/market/BTC",async r=>{var e;try{const s=await new Ae(r.env.COINGECKO_API_KEY||"CG-bsLZ4jVKKU72L2Jmn2jSgioV").getEnhancedMarketData("BTC");if((e=s.price_data)!=null&&e.bitcoin){const i=s.price_data.bitcoin,a=i.usd_24h_change||0,n=i.usd?i.usd*a/100:0;return r.json({success:!0,crypto:"BTC",symbol:"BTCUSDT",price:i.usd,price_change_24h:n,price_change_percentage_24h:a,volume_24h:i.usd_24h_vol||0,market_cap:i.usd_market_cap||0,timestamp:new Date().toISOString(),status:"active",data:{symbol:"BTCUSDT",price:i.usd,price_change_24h:n,price_change_percentage_24h:a,volume_24h:i.usd_24h_vol||0,market_cap:i.usd_market_cap||0,timestamp:new Date().toISOString()}})}return r.json({success:!0,crypto:"BTC",price:94350.75,timestamp:new Date().toISOString(),status:"active"})}catch(t){return r.json({success:!1,error:t instanceof Error?t.message:"Market data unavailable",timestamp:new Date().toISOString()})}});T.get("/api/predictions/ETH",async r=>{try{const s=(await(await fetch(`${r.req.url.replace("/predictions/ETH","/market/ETH")}`)).json()).price||4620.5,a=await new Ie(r.env.DB).predictNextHours("ETH",24,s),n={id:Date.now()+"_ETH",crypto:"ETH",current_price:s,predicted_price:a.predicted_price,confidence:a.confidence_score,predicted_return:a.predicted_return,prediction_horizon:"24h",model_version:"TimesFM-v2.1",features_analyzed:["RSI Technical Analysis","EMA 20/50 Crossovers","Bollinger Bands Position","Price Momentum Indicators","ATR Volatility Analysis","Market Trend Patterns"],quantile_10:a.quantile_10,quantile_90:a.quantile_90,analysis:{trend:a.predicted_return>.005?"bullish":a.predicted_return<-.005?"bearish":"sideways",volatility:a.confidence_score>.7?"low":"moderate",key_factors:[`Expected ${(a.predicted_return*100).toFixed(2)}% movement in 24h`,`Model confidence: ${(a.confidence_score*100).toFixed(1)}%`,`Analysis based on ${a.horizon_hours}h historical data`]},timestamp:new Date().toISOString()};return $.unshift(n),$.length>100&&($=$.slice(0,100)),r.json({success:!0,...n})}catch(e){return console.error("ETH TimesFM Prediction Error:",e),r.json({success:!1,error:"Failed to generate TimesFM prediction",timestamp:new Date().toISOString()})}});T.get("/api/predictions/BTC",async r=>{try{const s=(await(await fetch(`${r.req.url.replace("/predictions/BTC","/market/BTC")}`)).json()).price||94350.75,a=await new Ie(r.env.DB).predictNextHours("BTC",24,s),n={id:Date.now()+"_BTC",crypto:"BTC",current_price:s,predicted_price:a.predicted_price,confidence:a.confidence_score,predicted_return:a.predicted_return,prediction_horizon:"24h",model_version:"TimesFM-v2.1",features_analyzed:["RSI Technical Analysis","EMA 20/50 Crossovers","Bollinger Bands Position","Price Momentum Indicators","ATR Volatility Analysis","Market Trend Patterns"],quantile_10:a.quantile_10,quantile_90:a.quantile_90,analysis:{trend:a.predicted_return>.005?"bullish":a.predicted_return<-.005?"bearish":"sideways",volatility:a.confidence_score>.7?"low":"moderate",key_factors:[`Expected ${(a.predicted_return*100).toFixed(2)}% movement in 24h`,`Model confidence: ${(a.confidence_score*100).toFixed(1)}%`,`Analysis based on ${a.horizon_hours}h historical data`]},timestamp:new Date().toISOString()};return $.unshift(n),$.length>100&&($=$.slice(0,100)),r.json({success:!0,...n})}catch(e){return console.error("BTC TimesFM Prediction Error:",e),r.json({success:!1,error:"Failed to generate TimesFM prediction",timestamp:new Date().toISOString()})}});T.get("/api/predictions/history",r=>r.json({success:!0,predictions:$,total_count:$.length,timestamp:new Date().toISOString()}));T.get("/api/trades/history",r=>r.json({success:!0,trades:ne,total_count:ne.length,timestamp:new Date().toISOString()}));T.post("/api/trades/execute",async r=>{try{const e=await r.req.json(),{crypto:t,action:s,amount:i,price:a}=e,n={id:Date.now()+"_"+t,crypto:t,action:s,amount:parseFloat(i),price:parseFloat(a),total:parseFloat(i)*parseFloat(a),status:"executed",timestamp:new Date().toISOString()};return ne.unshift(n),ne.length>50&&(ne=ne.slice(0,50)),r.json({success:!0,trade:n})}catch{return r.json({success:!1,error:"Failed to execute trade"})}});T.get("/api/portfolio",r=>r.json({success:!0,balance:1e4,positions:2,timestamp:new Date().toISOString()}));T.get("/login",r=>r.html(`
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ETH Trader Pro - Login</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            background: #000000;
            min-height: 100vh;
        }
        .glass-morphism {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            box-shadow: 0 25px 45px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen">
    <div class="glass-morphism rounded-2xl p-8 w-full max-w-md">
        <div class="text-center mb-6">
            <h1 class="text-2xl font-bold text-white mb-2">🚀 ETH Trader Pro</h1>
            <p class="text-gray-300">Entrez le code d'accès</p>
        </div>
        
        <form id="loginForm">
            <div class="mb-4">
                <label class="block text-gray-200 text-sm font-medium mb-2">
                    <i class="fas fa-key mr-2"></i>Code d'Accès
                </label>
                <input 
                    type="password" 
                    id="accessCode" 
                    class="w-full px-4 py-3 rounded-lg text-white bg-white/10 border border-white/20 focus:outline-none focus:border-blue-400"
                    placeholder="Entrez votre code"
                    maxlength="10"
                    required
                >
            </div>
            
            <div id="errorMessage" class="hidden bg-red-500/20 border border-red-500/40 text-red-200 px-4 py-2 rounded-lg text-sm mb-4">
                <i class="fas fa-exclamation-triangle mr-2"></i>
                Code d'accès incorrect
            </div>
            
            <button 
                type="submit"
                class="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 shadow-lg">
                <i class="fas fa-sign-in-alt mr-2"></i>
                Se Connecter
            </button>
        </form>
    </div>

    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const accessCode = document.getElementById('accessCode').value;
            const errorMessage = document.getElementById('errorMessage');
            
            if (accessCode === '12345') {
                // Stocker l'authentification
                sessionStorage.setItem('eth_trader_authenticated', 'true');
                sessionStorage.setItem('eth_trader_login_time', new Date().getTime().toString());
                
                // Rediriger vers le terminal standalone
                window.location.href = '/terminal';
            } else {
                // Afficher l'erreur
                errorMessage.classList.remove('hidden');
                document.getElementById('accessCode').value = '';
                
                setTimeout(() => {
                    errorMessage.classList.add('hidden');
                }, 3000);
            }
        });

        // Auto-focus
        document.getElementById('accessCode').focus();
    <\/script>
</body>
</html>
  `));T.get("/ethereum-terminal-standalone.html",r=>{const e=require("fs"),t=require("path");try{const s=t.join(process.cwd(),"dist","ethereum-terminal-standalone.html"),i=e.readFileSync(s,"utf8");return r.html(i)}catch{return r.html(`
      <!DOCTYPE html>
      <html>
      <head>
          <title>Terminal Loading...</title>
          <script src="https://cdn.tailwindcss.com"><\/script>
      </head>
      <body class="bg-gray-900 text-white flex items-center justify-center min-h-screen">
          <div class="text-center">
              <h1 class="text-2xl mb-4">🚀 ETH Trader Terminal</h1>
              <p>Terminal en cours de chargement...</p>
              <div class="mt-4">
                  <a href="/login" class="text-blue-400 hover:underline">← Retour au login</a>
              </div>
          </div>
      </body>
      </html>
    `)}});T.get("/",r=>r.html(`
<!DOCTYPE html>
<html>
<head>
    <title>ETH Trader Pro - Chargement...</title>
</head>
<body>
    <script>
        // Vérifier l'authentification
        const isAuthenticated = sessionStorage.getItem('eth_trader_authenticated');
        
        if (isAuthenticated === 'true') {
            // Rediriger vers le terminal
            window.location.href = '/terminal';
        } else {
            // Rediriger vers login
            window.location.href = '/login';
        }
    <\/script>
</body>
</html>
  `));T.get("/terminal",r=>r.html(`<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ethereum AI Trading Terminal - Neural Network Powered Trading</title>
    <script src="https://cdn.tailwindcss.com"><\/script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"><\/script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: #000000;
            min-height: 100vh;
            background-attachment: fixed;
        }

        .neural-network-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            opacity: 0.1;
            background-image: radial-gradient(circle at 20% 50%, rgba(147, 51, 234, 0.3) 0%, transparent 50%),
                              radial-gradient(circle at 80% 20%, rgba(59, 130, 246, 0.3) 0%, transparent 50%),
                              radial-gradient(circle at 40% 80%, rgba(16, 185, 129, 0.3) 0%, transparent 50%);
            animation: neural-pulse 8s ease-in-out infinite;
        }

        @keyframes neural-pulse {
            0%, 100% {
                transform: scale(1);
                opacity: 0.1;
            }
            50% {
                transform: scale(1.1);
                opacity: 0.15;
            }
        }

        .glassmorphism {
            backdrop-filter: blur(16px) saturate(180%);
            -webkit-backdrop-filter: blur(16px) saturate(180%);
            background: rgba(17, 25, 40, 0.85);
            border: 1px solid rgba(255, 255, 255, 0.125);
            box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.37);
            transition: all 0.3s ease;
        }

        .glassmorphism:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 40px 0 rgba(31, 38, 135, 0.5);
        }

        .metric-card {
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);
            transition: all 0.2s ease;
            position: relative;
            overflow: hidden;
        }

        .metric-card:hover {
            transform: translateY(-1px) scale(1.02);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
        }

        .holographic-text {
            background: linear-gradient(
                90deg,
                #ff006e,
                #8338ec,
                #3a86ff,
                #06ffa5,
                #ffbe0b,
                #fb5607,
                #ff006e
            );
            background-size: 400%;
            -webkit-background-clip: text;
            background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: holographic 4s ease-in-out infinite;
        }

        @keyframes holographic {
            0%, 100% {
                background-position: 0% 50%;
            }
            50% {
                background-position: 100% 50%;
            }
        }

        .eth-glow {
            filter: drop-shadow(0 0 10px rgba(147, 51, 234, 0.6));
            animation: eth-pulse 3s ease-in-out infinite;
        }

        @keyframes eth-pulse {
            0%, 100% {
                filter: drop-shadow(0 0 10px rgba(147, 51, 234, 0.6));
            }
            50% {
                filter: drop-shadow(0 0 20px rgba(147, 51, 234, 0.9)) drop-shadow(0 0 30px rgba(59, 130, 246, 0.4));
            }
        }

        button:hover {
            transform: translateY(-2px) scale(1.02);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.4);
        }

        button:active {
            transform: translateY(0) scale(0.98);
        }

        .circuit-pattern {
            background-image: 
                radial-gradient(circle at 25% 25%, rgba(147, 51, 234, 0.2) 2px, transparent 2px),
                radial-gradient(circle at 75% 75%, rgba(59, 130, 246, 0.2) 2px, transparent 2px),
                linear-gradient(0deg, rgba(147, 51, 234, 0.1) 50%, transparent 50%),
                linear-gradient(90deg, rgba(59, 130, 246, 0.1) 50%, transparent 50%);
            background-size: 40px 40px, 40px 40px, 20px 20px, 20px 20px;
            background-position: 0 0, 20px 20px, 0 0, 0 0;
        }

        .fadeInUp {
            animation: fadeInUp 0.6s ease-out;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body class="bg-gray-900 text-white">
    <!-- Neural Network Background -->
    <div class="neural-network-bg"></div>
    
    <!-- Loading Screen -->
    <div id="loading" class="fixed inset-0 bg-gray-900/95 flex items-center justify-center z-50">
        <div class="text-center">
            <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-400 mx-auto mb-4"></div>
            <h2 class="text-xl font-semibold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent mb-2">Ethereum AI Trading Terminal</h2>
            <p id="loadingText" class="text-gray-400">Initialisation du réseau neuronal...</p>
        </div>
    </div>

    <!-- Main Dashboard -->
    <div id="dashboard" class="hidden min-h-screen bg-gradient-to-br from-gray-900/90 via-purple-900/90 to-blue-900/90 backdrop-blur-sm circuit-pattern">
        <!-- Header -->
        <header class="bg-gradient-to-r from-purple-900/30 via-blue-900/30 to-purple-900/30 backdrop-blur-lg border-b border-purple-500/30 glassmorphism">
            <div class="container mx-auto px-6 py-4">
                <div class="flex flex-col md:flex-row justify-between items-center">
                    <div class="flex items-center space-x-4 mb-4 md:mb-0">
                        <div class="text-2xl eth-glow">⚡</div>
                        <div>
                            <h1 class="text-2xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent holographic-text">
                                Ethereum AI Trading Terminal
                            </h1>
                            <p class="text-purple-300 text-sm">Neural Network Powered Trading System</p>
                        </div>
                    </div>
                    
                    <div class="flex items-center space-x-4">
                        <!-- Crypto Selector avec support ETH/BTC -->
                        <div class="flex items-center space-x-2">
                            <label class="text-sm text-purple-300 font-medium">Asset:</label>
                            <select id="cryptoSelector" class="bg-gradient-to-r from-purple-900/50 to-blue-900/50 border border-purple-500/30 rounded-lg px-3 py-2 text-white focus:border-purple-400 focus:ring-2 focus:ring-purple-400/20 backdrop-blur-sm">
                                <option value="ETH">⚡ Ethereum (ETH)</option>
                                <option value="BTC">₿ Bitcoin (BTC)</option>
                            </select>
                        </div>
                        <div class="bg-gradient-to-r from-purple-500/20 to-blue-500/20 backdrop-blur-sm px-4 py-2 rounded-lg border border-purple-500/30">
                            <span class="text-sm text-purple-300 font-medium">🤖 AI Mode</span>
                        </div>
                        <div class="flex items-center space-x-1">
                            <div class="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                            <span class="text-xs text-gray-400">Live</span>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Dashboard Content -->
        <div class="container mx-auto px-6 py-8">
            <div id="dashboardContent" class="fadeInUp">
                <!-- Content will be injected here -->
            </div>
        </div>
    </div>

    <script>
        class EthereumAITradingTerminal {
            constructor() {
                this.currentCrypto = 'ETH';
                this.priceChart = null;
                this.isAutoRefreshEnabled = true;
                this.refreshInterval = null;
                this.predictionsHistory = [];
                this.tradesHistory = [];
                
                console.log('🚀 Ethereum AI Trading Terminal - Initialisation...');
                this.init();
            }

            async init() {
                // Animation de chargement progressive
                const loadingSteps = [
                    { text: 'Initialisation des réseaux neuronaux...', delay: 500 },
                    { text: 'Connexion aux flux de données en temps réel...', delay: 1000 },
                    { text: 'Chargement des modèles TimesFM...', delay: 1500 },
                    { text: 'Configuration du terminal AI...', delay: 2000 }
                ];
                
                const loadingText = document.getElementById('loadingText');
                let currentStep = 0;
                
                const updateLoading = () => {
                    if (currentStep < loadingSteps.length) {
                        setTimeout(() => {
                            loadingText.textContent = loadingSteps[currentStep].text;
                            currentStep++;
                            updateLoading();
                        }, loadingSteps[currentStep]?.delay || 500);
                    } else {
                        setTimeout(() => {
                            this.loadTerminal();
                        }, 500);
                    }
                };
                
                updateLoading();
            }

            async loadTerminal() {
                try {
                    const dashboardData = await this.getMarketData();
                    await this.loadPredictionsHistory();
                    await this.loadTradesHistory();
                    this.renderTerminal(dashboardData);
                    this.setupEventListeners();
                    
                    document.getElementById('loading').classList.add('hidden');
                    document.getElementById('dashboard').classList.remove('hidden');
                    
                } catch (error) {
                    console.error('Erreur lors du chargement du terminal:', error);
                    // Fallback to demo data if API fails
                    const dashboardData = this.getDemoData();
                    this.renderTerminal(dashboardData);
                    this.setupEventListeners();
                    document.getElementById('loading').classList.add('hidden');
                    document.getElementById('dashboard').classList.remove('hidden');
                }
            }

            async getMarketData() {
                try {
                    const response = await fetch('/api/market/' + this.currentCrypto);
                    const marketData = await response.json();
                    
                    if (!marketData.success) {
                        throw new Error('Market data fetch failed');
                    }
                    
                    // Get prediction data
                    const predictionResponse = await fetch('/api/predictions/' + this.currentCrypto);
                    const predictionData = await predictionResponse.json();
                    
                    return {
                        current_price: marketData.price,
                        current_balance: 10000.00,
                        active_positions: [
                            {
                                type: 'long',
                                entry_price: marketData.price * 0.98,
                                pnl: 2.35
                            },
                            {
                                type: 'short', 
                                entry_price: marketData.price * 1.02,
                                pnl: -1.15
                            }
                        ],
                        latest_predictions: predictionData.success ? [predictionData] : [],
                        market_data: {
                            volume_24h: marketData.volume_24h || (this.currentCrypto === 'ETH' ? 15.8e9 : 28.3e9),
                            market_cap: marketData.market_cap || (this.currentCrypto === 'ETH' ? 556e9 : 1875e9),
                            price_change_percentage_24h: marketData.price_change_24h || 2.45
                        }
                    };
                } catch (error) {
                    console.error('Failed to fetch real market data, using fallback:', error);
                    return this.getDemoData();
                }
            }

            getDemoData() {
                const basePrice = this.currentCrypto === 'ETH' ? 4620.50 : 94350.75;
                
                return {
                    current_price: basePrice,
                    current_balance: 10000.00,
                    active_positions: [
                        {
                            type: 'long',
                            entry_price: basePrice * 0.98,
                            pnl: 2.35
                        },
                        {
                            type: 'short', 
                            entry_price: basePrice * 1.02,
                            pnl: -1.15
                        }
                    ],
                    latest_predictions: [
                        {
                            predicted_price: basePrice * 1.025,
                            predicted_return: 0.025,
                            confidence_score: 0.78,
                            quantile_10: basePrice * 0.95,
                            quantile_90: basePrice * 1.08
                        }
                    ],
                    market_data: {
                        volume_24h: this.currentCrypto === 'ETH' ? 15.8e9 : 28.3e9,
                        market_cap: this.currentCrypto === 'ETH' ? 556e9 : 1875e9,
                        price_change_percentage_24h: 2.45
                    }
                };
            }

            async loadPredictionsHistory() {
                try {
                    const response = await fetch('/api/predictions/history');
                    const data = await response.json();
                    this.predictionsHistory = data.success ? data.predictions : [];
                } catch (error) {
                    console.error('Failed to load predictions history:', error);
                    this.predictionsHistory = [];
                }
            }

            async loadTradesHistory() {
                try {
                    const response = await fetch('/api/trades/history');
                    const data = await response.json();
                    this.tradesHistory = data.success ? data.trades : [];
                } catch (error) {
                    console.error('Failed to load trades history:', error);
                    this.tradesHistory = [];
                }
            }

            renderTerminal(dashboard) {
                const cryptoIcon = this.currentCrypto === 'ETH' ? '⚡' : '₿';
                const cryptoColor = this.currentCrypto === 'ETH' ? 'purple' : 'orange';
                const latestPrediction = dashboard.latest_predictions?.[0];
                
                const content = \`
                    <!-- Ethereum AI Trading Terminal Header -->
                    <div class="ethereum-ai-header mb-8">
                        <div class="flex items-center justify-between glassmorphism rounded-2xl p-6 border border-purple-500/30">
                            <div class="flex items-center space-x-4">
                                <div class="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-600 rounded-xl flex items-center justify-center text-2xl">\${cryptoIcon}</div>
                                <div>
                                    <h1 class="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                                        \${this.currentCrypto} AI Trading Terminal
                                    </h1>
                                    <p class="text-purple-300">Neural Network Powered Trading System</p>
                                </div>
                            </div>
                            <div class="flex items-center space-x-4">
                                <div class="ai-status-indicator">
                                    <div class="flex items-center space-x-2 bg-green-500/20 px-4 py-2 rounded-lg">
                                        <div class="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                                        <span class="text-green-300 text-sm font-medium">AI System Online</span>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <div class="text-2xl font-bold text-white">$\${dashboard.current_price?.toLocaleString() || 'N/A'}</div>
                                    <div class="text-sm text-purple-300">\${this.currentCrypto}/USD</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Main Terminal Grid -->
                    <div class="ethereum-ai-grid grid grid-cols-1 lg:grid-cols-3 gap-6 fadeInUp">
                        <!-- Left Column: Market Analysis -->
                        <div class="lg:col-span-2 space-y-6">
                            <!-- ETH Market Analysis -->
                            <div class="ethereum-market-analysis glassmorphism rounded-2xl p-6 border border-\${cryptoColor}-500/30">
                                <div class="flex items-center justify-between mb-6">
                                    <h2 class="text-xl font-bold text-white flex items-center">
                                        <span class="mr-3">📈</span>
                                        \${this.currentCrypto} Market Analysis
                                    </h2>
                                    <div class="text-sm text-\${cryptoColor}-300">Live Data • \${cryptoIcon}</div>
                                </div>
                                
                                <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                                    <div class="metric-card bg-purple-900/30 p-4 rounded-lg border border-purple-500/20">
                                        <div class="text-purple-300 text-sm">Current Price</div>
                                        <div class="text-2xl font-bold text-white">$\${dashboard.current_price?.toLocaleString() || 'N/A'}</div>
                                        <div class="text-green-400 text-xs">+2.4%</div>
                                    </div>
                                    <div class="metric-card bg-blue-900/30 p-4 rounded-lg border border-blue-500/20">
                                        <div class="text-blue-300 text-sm">24h Volume</div>
                                        <div class="text-xl font-bold text-white">\${dashboard.market_data?.volume_24h ? '$' + (dashboard.market_data.volume_24h / 1e9).toFixed(2) + 'B' : 'N/A'}</div>
                                        <div class="text-blue-400 text-xs">High Activity</div>
                                    </div>
                                    <div class="metric-card bg-green-900/30 p-4 rounded-lg border border-green-500/20">
                                        <div class="text-green-300 text-sm">Market Cap</div>
                                        <div class="text-xl font-bold text-white">\${dashboard.market_data?.market_cap ? '$' + (dashboard.market_data.market_cap / 1e9).toFixed(0) + 'B' : 'N/A'}</div>
                                        <div class="text-green-400 text-xs">Rank #\${this.currentCrypto === 'ETH' ? '2' : '1'}</div>
                                    </div>
                                    <div class="metric-card bg-orange-900/30 p-4 rounded-lg border border-orange-500/20">
                                        <div class="text-orange-300 text-sm">Volatility</div>
                                        <div class="text-xl font-bold text-white">\${dashboard.market_data?.price_change_percentage_24h ? Math.abs(dashboard.market_data.price_change_percentage_24h).toFixed(1) + '%' : 'N/A'}</div>
                                        <div class="text-orange-400 text-xs">Moderate</div>
                                    </div>
                                </div>
                                
                                <!-- Price Chart -->
                                <div class="chart-container bg-black/30 rounded-lg p-4 h-64 flex items-center justify-center border border-gray-600/30">
                                    <canvas id="cryptoPriceChart" class="w-full h-full"></canvas>
                                </div>
                            </div>

                            <!-- TimesFM Neural Predictions -->
                            <div class="timesfm-neural glassmorphism rounded-2xl p-6 border border-blue-500/30">
                                <div class="flex items-center justify-between mb-6">
                                    <h2 class="text-xl font-bold text-white flex items-center">
                                        <span class="mr-3">🧠</span>
                                        TimesFM Neural Predictions
                                    </h2>
                                    <div class="flex items-center space-x-2">
                                        <div class="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                                        <span class="text-blue-300 text-sm">AI Computing</span>
                                    </div>
                                </div>
                                
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div class="prediction-card bg-blue-900/40 p-4 rounded-lg border border-blue-400/30">
                                        <div class="text-blue-300 text-sm mb-2">24h Prediction</div>
                                        <div class="text-2xl font-bold text-white mb-1">
                                            $\${latestPrediction?.predicted_price?.toLocaleString() || 'Computing...'}
                                        </div>
                                        <div class="text-xs text-blue-400">
                                            Confidence: \${latestPrediction?.confidence_score ? (latestPrediction.confidence_score * 100).toFixed(1) + '%' : 'N/A'}
                                        </div>
                                    </div>
                                    
                                    <div class="prediction-card bg-green-900/40 p-4 rounded-lg border border-green-400/30">
                                        <div class="text-green-300 text-sm mb-2">Expected Return</div>
                                        <div class="text-2xl font-bold \${latestPrediction?.predicted_return && latestPrediction.predicted_return > 0 ? 'text-green-400' : 'text-red-400'} mb-1">
                                            \${latestPrediction?.predicted_return ? (latestPrediction.predicted_return * 100).toFixed(2) + '%' : 'N/A'}
                                        </div>
                                        <div class="text-xs text-green-400">24h Horizon</div>
                                    </div>
                                    
                                    <div class="prediction-card bg-purple-900/40 p-4 rounded-lg border border-purple-400/30">
                                        <div class="text-purple-300 text-sm mb-2">Risk Range</div>
                                        <div class="text-sm font-bold text-white mb-1">
                                            \${latestPrediction?.quantile_10 ? '$' + latestPrediction.quantile_10.toLocaleString() : 'N/A'} - \${latestPrediction?.quantile_90 ? '$' + latestPrediction.quantile_90.toLocaleString() : 'N/A'}
                                        </div>
                                        <div class="text-xs text-purple-400">90% Confidence</div>
                                    </div>
                                </div>
                                
                                <!-- Neural Network Activity -->
                                <div class="mt-4 p-4 bg-black/30 rounded-lg border border-gray-600/30">
                                    <div class="text-sm text-gray-300 mb-2">Neural Network Activity:</div>
                                    <div class="flex items-center space-x-4 text-xs">
                                        <div class="flex items-center space-x-1">
                                            <div class="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                                            <span class="text-green-300">Pattern Recognition</span>
                                        </div>
                                        <div class="flex items-center space-x-1">
                                            <div class="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                                            <span class="text-blue-300">Time Series Analysis</span>
                                        </div>
                                        <div class="flex items-center space-x-1">
                                            <div class="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                                            <span class="text-purple-300">Market Sentiment</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Right Column: Portfolio & Controls -->
                        <div class="space-y-6">
                            <!-- Portfolio -->
                            <div class="portfolio-section glassmorphism rounded-2xl p-6 border border-green-500/30">
                                <h2 class="text-xl font-bold text-white flex items-center mb-6">
                                    <span class="mr-3">💼</span>
                                    Portfolio
                                </h2>
                                
                                <div class="space-y-4">
                                    <div class="balance-card bg-green-900/30 p-4 rounded-lg border border-green-500/20">
                                        <div class="text-green-300 text-sm">Total Balance</div>
                                        <div class="text-2xl font-bold text-white">
                                            $\${dashboard.current_balance?.toLocaleString() || '10,000'}
                                        </div>
                                        <div class="text-green-400 text-xs">USD</div>
                                    </div>
                                    
                                    <div class="positions-summary">
                                        <div class="text-sm text-gray-300 mb-2">Active Positions:</div>
                                        <div class="space-y-2">
                                            \${dashboard.active_positions?.length ? dashboard.active_positions.map(position => \`
                                                <div class="position-item bg-gray-800/50 p-3 rounded-lg border border-gray-600/30">
                                                    <div class="flex justify-between items-center">
                                                        <div class="text-white font-medium">\${position.type?.toUpperCase() || 'N/A'}</div>
                                                        <div class="\${position.pnl && position.pnl > 0 ? 'text-green-400' : 'text-red-400'}">
                                                            \${position.pnl ? (position.pnl > 0 ? '+' : '') + position.pnl.toFixed(2) + '%' : 'N/A'}
                                                        </div>
                                                    </div>
                                                    <div class="text-xs text-gray-400 mt-1">
                                                        Entry: $\${position.entry_price?.toLocaleString() || 'N/A'}
                                                    </div>
                                                </div>
                                            \`).join('') : '<div class="text-gray-500 text-center py-4">No Active Positions</div>'}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Predictions History -->
                            <div class="predictions-history glassmorphism rounded-2xl p-6 border border-blue-500/30 mb-6">
                                <div class="flex items-center justify-between mb-4">
                                    <h2 class="text-xl font-bold text-white flex items-center">
                                        <span class="mr-3">📊</span>
                                        Predictions History
                                    </h2>
                                    <div class="text-sm text-blue-300">\${this.predictionsHistory.length} predictions</div>
                                </div>
                                
                                <div class="predictions-list max-h-64 overflow-y-auto space-y-2">
                                    \${this.predictionsHistory.slice(0, 5).map(prediction => \`
                                        <div class="prediction-item bg-gray-800/50 p-3 rounded-lg border border-gray-600/30 cursor-pointer hover:bg-gray-700/50 transition-colors" data-prediction-id="\${prediction.id}">
                                            <div class="flex justify-between items-center">
                                                <div class="text-white font-medium">\${prediction.crypto} • \${prediction.confidence ? (prediction.confidence * 100).toFixed(1) : 'N/A'}% confidence</div>
                                                <div class="text-sm text-gray-400">\${new Date(prediction.timestamp).toLocaleTimeString()}</div>
                                            </div>
                                            <div class="text-sm text-gray-300 mt-1">
                                                Predicted: $\${prediction.predicted_price?.toLocaleString() || 'N/A'}
                                            </div>
                                        </div>
                                    \`).join('') || '<div class="text-gray-500 text-center py-4">No predictions yet</div>'}
                                </div>
                            </div>

                            <!-- Trade History -->
                            <div class="trades-history glassmorphism rounded-2xl p-6 border border-green-500/30 mb-6">
                                <div class="flex items-center justify-between mb-4">
                                    <h2 class="text-xl font-bold text-white flex items-center">
                                        <span class="mr-3">📈</span>
                                        Trade History
                                    </h2>
                                    <div class="text-sm text-green-300">\${this.tradesHistory.length} trades</div>
                                </div>
                                
                                <div class="trades-list max-h-64 overflow-y-auto space-y-2">
                                    \${this.tradesHistory.slice(0, 5).map(trade => \`
                                        <div class="trade-item bg-gray-800/50 p-3 rounded-lg border border-gray-600/30">
                                            <div class="flex justify-between items-center">
                                                <div class="text-white font-medium">\${trade.crypto} • \${trade.action}</div>
                                                <div class="text-sm text-gray-400">\${new Date(trade.timestamp).toLocaleTimeString()}</div>
                                            </div>
                                            <div class="text-sm text-gray-300 mt-1">
                                                \${trade.amount} @ $\${trade.price?.toLocaleString() || 'N/A'}
                                            </div>
                                        </div>
                                    \`).join('') || '<div class="text-gray-500 text-center py-4">No trades yet</div>'}
                                </div>
                            </div>

                            <!-- Control Panel -->
                            <div class="control-panel glassmorphism rounded-2xl p-6 border border-red-500/30">
                                <h2 class="text-xl font-bold text-white flex items-center mb-6">
                                    <span class="mr-3">🎛️</span>
                                    Control Panel
                                </h2>
                                
                                <div class="space-y-3">
                                    <button id="generatePrediction" class="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 transform hover:scale-105">
                                        🧠 Generate Prediction
                                    </button>
                                    
                                    <button id="executeTradeSignal" class="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 transform hover:scale-105">
                                        📈 Execute Trade Signal
                                    </button>
                                    
                                    <button id="updateMarketData" class="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 transform hover:scale-105">
                                        📊 Update Market Data
                                    </button>
                                    
                                    <button id="refreshDashboard" class="w-full bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800 text-white font-medium py-3 px-4 rounded-lg transition-all duration-200 transform hover:scale-105">
                                        🔄 Refresh Dashboard
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                \`;
                
                document.getElementById('dashboardContent').innerHTML = content;
                
                // Initialiser le graphique
                setTimeout(() => {
                    this.initializePriceChart(dashboard);
                }, 100);
            }

            setupEventListeners() {
                // Sélecteur de crypto
                const cryptoSelector = document.getElementById('cryptoSelector');
                if (cryptoSelector) {
                    cryptoSelector.value = this.currentCrypto;
                    cryptoSelector.addEventListener('change', (e) => {
                        const newCrypto = e.target.value;
                        console.log(\`Changement de crypto: \${this.currentCrypto} → \${newCrypto}\`);
                        this.currentCrypto = newCrypto;
                        this.loadTerminal();
                    });
                }

                // Boutons de contrôle - fonctions réelles
                const buttons = {
                    generatePrediction: async () => {
                        this.showMessage('🧠 Génération de nouvelle prédiction...', 'info');
                        try {
                            const response = await fetch('/api/predictions/' + this.currentCrypto);
                            const data = await response.json();
                            if (data.success) {
                                await this.loadPredictionsHistory();
                                this.loadTerminal();
                                this.showMessage('✅ Nouvelle prédiction générée', 'success');
                            }
                        } catch (error) {
                            this.showMessage('❌ Erreur lors de la génération', 'error');
                        }
                    },
                    executeTradeSignal: async () => {
                        this.showMessage('📈 Exécution du signal de trading...', 'info');
                        try {
                            const marketResponse = await fetch('/api/market/' + this.currentCrypto);
                            const marketData = await marketResponse.json();
                            
                            const tradeData = {
                                crypto: this.currentCrypto,
                                action: Math.random() > 0.5 ? 'BUY' : 'SELL',
                                amount: 0.1,
                                price: marketData.price
                            };
                            
                            const response = await fetch('/api/trades/execute', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify(tradeData)
                            });
                            
                            if (response.ok) {
                                await this.loadTradesHistory();
                                this.loadTerminal();
                                this.showMessage('✅ Trade exécuté avec succès', 'success');
                            }
                        } catch (error) {
                            this.showMessage('❌ Erreur lors du trade', 'error');
                        }
                    },
                    updateMarketData: () => {
                        this.showMessage('📊 Mise à jour des données de marché...', 'info');
                        this.loadTerminal();
                    },
                    refreshDashboard: () => {
                        this.showMessage('🔄 Actualisation du dashboard...', 'info');
                        this.loadTerminal();
                    }
                };

                Object.keys(buttons).forEach(id => {
                    const btn = document.getElementById(id);
                    if (btn) {
                        btn.addEventListener('click', buttons[id]);
                    }
                });

                // Predictions history click handlers
                document.querySelectorAll('[data-prediction-id]').forEach(item => {
                    item.addEventListener('click', (e) => {
                        const predictionId = e.currentTarget.getAttribute('data-prediction-id');
                        this.showPredictionAnalysis(predictionId);
                    });
                });
            }

            initializePriceChart(dashboard) {
                const canvas = document.getElementById('cryptoPriceChart');
                if (!canvas) return;

                const ctx = canvas.getContext('2d');
                const currentPrice = dashboard.current_price || (this.currentCrypto === 'ETH' ? 4600 : 94000);
                
                // RESTAURATION: 400+ points de données - 1 POINT PAR HEURE comme stratégie originale
                const hours = 400; // 400+ heures pour TimesFM (stratégie originale)
                const pointsPerHour = 1; // 1 POINT PAR HEURE - CRUCIAL pour TimesFM
                const totalPoints = hours * pointsPerHour;
                const data = [];
                const labels = [];

                // Générer 400+ points de données (1 par heure - TimesFM requirement)
                for (let i = totalPoints; i >= 0; i--) {
                    const time = new Date(Date.now() - i * 60 * 60 * 1000); // 1 heure exacte
                    labels.push(time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
                    
                    // Variation réaliste pour TimesFM (stratégie originale)
                    const variation = (Math.random() - 0.5) * 0.02;
                    const price = currentPrice * (1 + variation * (i / totalPoints));
                    data.push(price);
                }

                if (this.priceChart) {
                    this.priceChart.destroy();
                }

                this.priceChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels.filter((_, i) => i % 4 === 0),
                        datasets: [{
                            label: \`\${this.currentCrypto} Price (USD)\`,
                            data: data.filter((_, i) => i % 4 === 0),
                            borderColor: this.currentCrypto === 'ETH' ? 'rgb(147, 51, 234)' : 'rgb(249, 115, 22)',
                            backgroundColor: this.currentCrypto === 'ETH' ? 'rgba(147, 51, 234, 0.1)' : 'rgba(249, 115, 22, 0.1)',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.4,
                            pointRadius: 0,
                            pointHoverRadius: 6
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: {
                                display: false
                            }
                        },
                        scales: {
                            x: {
                                grid: {
                                    color: 'rgba(75, 85, 99, 0.3)'
                                },
                                ticks: {
                                    color: 'rgba(156, 163, 175, 0.8)',
                                    maxTicksLimit: 8
                                }
                            },
                            y: {
                                grid: {
                                    color: 'rgba(75, 85, 99, 0.3)'
                                },
                                ticks: {
                                    color: 'rgba(156, 163, 175, 0.8)',
                                    callback: function(value) {
                                        return '$' + value.toLocaleString();
                                    }
                                }
                            }
                        }
                    }
                });
            }

            showPredictionAnalysis(predictionId) {
                const prediction = this.predictionsHistory.find(p => p.id === predictionId);
                if (!prediction) return;

                const modal = document.createElement('div');
                modal.className = 'fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4';
                modal.innerHTML = \`
                    <div class="bg-gray-900 rounded-2xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto glassmorphism">
                        <div class="flex items-center justify-between mb-6">
                            <h2 class="text-2xl font-bold text-white">🧠 Prediction Analysis</h2>
                            <button class="text-gray-400 hover:text-white text-2xl" onclick="this.parentElement.parentElement.parentElement.remove()">&times;</button>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                            <div class="bg-blue-900/30 p-4 rounded-lg">
                                <div class="text-blue-300 text-sm">Asset</div>
                                <div class="text-2xl font-bold text-white">\${prediction.crypto}</div>
                            </div>
                            <div class="bg-purple-900/30 p-4 rounded-lg">
                                <div class="text-purple-300 text-sm">Confidence</div>
                                <div class="text-2xl font-bold text-white">\${(prediction.confidence * 100).toFixed(1)}%</div>
                            </div>
                            <div class="bg-green-900/30 p-4 rounded-lg">
                                <div class="text-green-300 text-sm">Current Price</div>
                                <div class="text-xl font-bold text-white">$\${prediction.current_price?.toLocaleString()}</div>
                            </div>
                            <div class="bg-orange-900/30 p-4 rounded-lg">
                                <div class="text-orange-300 text-sm">Predicted Price</div>
                                <div class="text-xl font-bold text-white">$\${prediction.predicted_price?.toLocaleString()}</div>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <h3 class="text-lg font-semibold text-white mb-3">📊 Analysis Details</h3>
                            <div class="bg-gray-800/50 p-4 rounded-lg">
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                                    <div>
                                        <div class="text-gray-300 mb-2">Model Version:</div>
                                        <div class="text-white font-medium">\${prediction.model_version}</div>
                                    </div>
                                    <div>
                                        <div class="text-gray-300 mb-2">Prediction Horizon:</div>
                                        <div class="text-white font-medium">\${prediction.prediction_horizon}</div>
                                    </div>
                                    <div>
                                        <div class="text-gray-300 mb-2">Trend:</div>
                                        <div class="text-white font-medium capitalize">\${prediction.analysis?.trend || 'N/A'}</div>
                                    </div>
                                    <div>
                                        <div class="text-gray-300 mb-2">Volatility:</div>
                                        <div class="text-white font-medium">\${prediction.analysis?.volatility || 'N/A'}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <h3 class="text-lg font-semibold text-white mb-3">🔍 Features Analyzed</h3>
                            <div class="bg-gray-800/50 p-4 rounded-lg">
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
                                    \${prediction.features_analyzed?.map(feature => \`
                                        <div class="flex items-center space-x-2">
                                            <div class="w-2 h-2 bg-blue-400 rounded-full"></div>
                                            <span class="text-gray-300 text-sm">\${feature}</span>
                                        </div>
                                    \`).join('') || '<div class="text-gray-500">No features data</div>'}
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <h3 class="text-lg font-semibold text-white mb-3">⚡ Key Factors</h3>
                            <div class="bg-gray-800/50 p-4 rounded-lg">
                                \${prediction.analysis?.key_factors?.map(factor => \`
                                    <div class="flex items-center space-x-2 mb-2">
                                        <div class="w-2 h-2 bg-green-400 rounded-full"></div>
                                        <span class="text-gray-300 text-sm">\${factor}</span>
                                    </div>
                                \`).join('') || '<div class="text-gray-500">No key factors data</div>'}
                            </div>
                        </div>
                        
                        <div class="bg-purple-900/20 p-4 rounded-lg">
                            <div class="text-purple-300 text-sm mb-2">Risk Range (90% Confidence)</div>
                            <div class="text-white font-medium">
                                $\${prediction.quantile_10?.toLocaleString()} - $\${prediction.quantile_90?.toLocaleString()}
                            </div>
                        </div>
                    </div>
                \`;
                
                document.body.appendChild(modal);
                
                // Close on backdrop click
                modal.addEventListener('click', (e) => {
                    if (e.target === modal) {
                        modal.remove();
                    }
                });
            }

            showMessage(message, type = 'info') {
                const colors = {
                    info: 'bg-blue-500',
                    success: 'bg-green-500',
                    error: 'bg-red-500'
                };
                
                const toast = document.createElement('div');
                toast.className = \`fixed top-4 right-4 \${colors[type]} text-white px-6 py-3 rounded-lg shadow-lg z-50 transition-all duration-300\`;
                toast.textContent = message;
                
                document.body.appendChild(toast);
                
                setTimeout(() => {
                    toast.remove();
                }, 3000);
            }
        }

        // Initialiser l'application au chargement de la page
        let terminal;
        document.addEventListener('DOMContentLoaded', () => {
            terminal = new EthereumAITradingTerminal();
        });
    <\/script>
</body>
</html>`));T.get("/api/automation/hourly",async r=>{var e,t,s,i,a,n;try{const o=Date.now(),c=new Ae(r.env.COINGECKO_API_KEY||"CG-bsLZ4jVKKU72L2Jmn2jSgioV"),l=new Ie(r.env.DB),d=new Tt(r.env.DB,r.env),h={cycle_type:"hourly",timestamp:new Date().toISOString(),data_collection:{status:"pending",eth:null,btc:null},predictions:{status:"pending",eth:null,btc:null},trading_signals:{status:"pending",eth:null,btc:null},errors:[]};try{const[m,b]=await Promise.all([c.getEnhancedMarketData("ETH"),c.getEnhancedMarketData("BTC")]);if((e=m.price_data)!=null&&e.ethereum){const g=m.price_data.ethereum;await r.env.DB.prepare(`
          INSERT INTO market_data (symbol, timestamp, open_price, high_price, low_price, close_price, volume, market_cap)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind("ETHUSDT",new Date().toISOString(),g.usd,g.usd,g.usd,g.usd,g.usd_24h_vol||0,g.usd_market_cap||0).run(),h.data_collection.eth={price:g.usd,volume:g.usd_24h_vol}}if((t=b.price_data)!=null&&t.bitcoin){const g=b.price_data.bitcoin;await r.env.DB.prepare(`
          INSERT INTO market_data (symbol, timestamp, open_price, high_price, low_price, close_price, volume, market_cap)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `).bind("BTCUSDT",new Date().toISOString(),g.usd,g.usd,g.usd,g.usd,g.usd_24h_vol||0,g.usd_market_cap||0).run(),h.data_collection.btc={price:g.usd,volume:g.usd_24h_vol}}h.data_collection.status="completed"}catch(m){h.errors.push(`Data collection failed: ${m instanceof Error?m.message:"Unknown error"}`)}try{const[m,b]=await Promise.all([l.predictNextHours("ETH",24,((s=h.data_collection.eth)==null?void 0:s.price)||4620),l.predictNextHours("BTC",24,((i=h.data_collection.btc)==null?void 0:i.price)||94350)]);h.predictions={status:"completed",eth:{predicted_price:m.predicted_price,confidence:m.confidence_score,return:m.predicted_return},btc:{predicted_price:b.predicted_price,confidence:b.confidence_score,return:b.predicted_return}}}catch(m){h.errors.push(`Predictions failed: ${m instanceof Error?m.message:"Unknown error"}`)}try{const[m,b]=await Promise.all([d.generateSignal("ETHUSDT",(a=h.data_collection.eth)==null?void 0:a.price),d.generateSignal("BTCUSDT",(n=h.data_collection.btc)==null?void 0:n.price)]),g=m.confidence>.59&&Math.abs(m.predicted_return||0)>.012,y=b.confidence>.59&&Math.abs(b.predicted_return||0)>.012;g&&m.action!=="hold"&&await d.executePaperTrade(m),y&&b.action!=="hold"&&await d.executePaperTrade(b),h.trading_signals={status:"completed",eth:{action:m.action,confidence:m.confidence,meets_threshold:g,executed:g&&m.action!=="hold"},btc:{action:b.action,confidence:b.confidence,meets_threshold:y,executed:y&&b.action!=="hold"}}}catch(m){h.errors.push(`Trading signals failed: ${m instanceof Error?m.message:"Unknown error"}`)}const p=Date.now()-o;return r.json({success:h.errors.length===0,execution_time_ms:p,...h})}catch(o){return r.json({success:!1,error:o instanceof Error?o.message:"Hourly automation failed",timestamp:new Date().toISOString()})}});T.get("/api/trading/check-positions",async r=>{var e,t,s,i;try{const a=new Tt(r.env.DB,r.env),n=new Ie(r.env.DB),o=new Ae(r.env.COINGECKO_API_KEY||"CG-bsLZ4jVKKU72L2Jmn2jSgioV"),[c,l]=await Promise.all([o.getEnhancedMarketData("ETH"),o.getEnhancedMarketData("BTC")]),d=((t=(e=c.price_data)==null?void 0:e.ethereum)==null?void 0:t.usd)||4620,h=((i=(s=l.price_data)==null?void 0:s.bitcoin)==null?void 0:i.usd)||94350,p={monitoring_cycle:"5min_positions",timestamp:new Date().toISOString(),eth:{price:d,positions_checked:0,positions_closed:0},btc:{price:h,positions_checked:0,positions_closed:0},total_closures:0};try{await a.checkStopLossAndTakeProfit(d);const m=await a.getActivePositions("ETHUSDT");p.eth.positions_checked=m.length;const b=await n.predictNextHours("ETH",4,d),g=await a.checkAndClosePositionsIntelligent(b,d);p.eth.positions_closed=g.positions_closed,p.total_closures+=g.positions_closed}catch(m){console.error("ETH position monitoring error:",m)}try{await a.checkStopLossAndTakeProfit(h);const m=await a.getActivePositions("BTCUSDT");p.btc.positions_checked=m.length;const b=await n.predictNextHours("BTC",4,h),g=await a.checkAndClosePositionsIntelligent(b,h);p.btc.positions_closed=g.positions_closed,p.total_closures+=g.positions_closed}catch(m){console.error("BTC position monitoring error:",m)}return r.json({success:!0,...p})}catch(a){return r.json({success:!1,error:a instanceof Error?a.message:"Position monitoring failed",timestamp:new Date().toISOString()})}});const Ke=new wt,vr=Object.assign({"/src/index.tsx":T});let Ct=!1;for(const[,r]of Object.entries(vr))r&&(Ke.all("*",e=>{let t;try{t=e.executionCtx}catch{}return r.fetch(e.req.raw,e.env,t)}),Ke.notFound(e=>{let t;try{t=e.executionCtx}catch{}return r.fetch(e.req.raw,e.env,t)}),Ct=!0);if(!Ct)throw new Error("Can't import modules from ['/src/index.ts','/src/index.tsx','/app/server.ts']");export{Ke as default};
